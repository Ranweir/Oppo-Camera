# OpenCam

An original Android camera app built with CameraX (Kotlin). Layout: top toolbar, preview,
zoom chips + arc zoom dial, mode strip, shutter row, and a drop-down menu panel.
All sizes are in dp / weights and the preview is sized from the real screen, so it adapts
to tall phones such as the Poco F1 (1080x2246).

## Screen map
- Top bar: flash (auto/on/off), EV slider, shutter sound, grid lines, menu
- Menu panel (menu icon, or tap the selected mode): aspect ratio 1:1 / 4:3 / 16:9 / Full,
  timer Off / 3 s / 10 s, Auto HDR, Watermark (date stamp), Interval shooting, Settings
- Right side of preview: AI enhance, Filters, Beauty
- Bottom-left of preview: interval shooting pill
- Zoom chips (0.6 / 1x / 2 / 5 where available), long-press or tap the selected chip for the dial
- Modes: PRO, VIDEO, PHOTO, PORTRAIT, NIGHT (swipe the preview or tap the strip)
- Shutter row: gallery thumbnail, shutter, front/back switch

## Build
Push this folder to GitHub. `.github/workflows/build.yml` builds `app-debug.apk` and uploads
it as an artifact (Actions tab > latest run > Artifacts).

Local build: JDK 17 + Android SDK + Gradle 8.5, then `gradle assembleDebug`.

## Notes
- Filters are not applied to recorded video.
- Beauty, Portrait, Night, HDR and AI enhance are software effects applied to the saved photo.
- Camera features depend on what the phone exposes through CameraX.
