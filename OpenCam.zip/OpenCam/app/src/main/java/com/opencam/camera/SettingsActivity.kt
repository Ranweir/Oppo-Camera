package com.opencam.camera

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/** Full-page camera settings (same look as OxyCam). Values are read by MainActivity in onResume. */
class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("opencam", Context.MODE_PRIVATE)
        val sv = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            fitsSystemWindows = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(40))
        }
        sv.addView(root)
        setContentView(sv)
        build()
    }

    private fun build() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "\u2190   Camera settings"
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(0, dp(8), 0, dp(12))
            setOnClickListener { finish() }
        })

        section("General")
        switchRow("Grid lines", "Rule-of-thirds grid in the viewfinder", "grid", false)
        choiceRow("Aspect ratio / image size", "ratio", listOf("1:1", "4:3", "16:9", "Full screen"), 1)
        switchRow("Shutter sound", null, "sound", true)
        switchRow("Mirror selfie", "Save selfies the way they look in the preview", "mirror", true)
        switchRow("Volume keys take photo", null, "volume", true)
        switchRow("Watermark", "Date stamp on saved photos", "wm", false)

        section("Zoom dial")
        switchRow("Zoom dial sound", "Tick sound while turning the zoom dial", "zoomsound", true)
        choiceRow("Zoom dial sound volume", "zoomvol", listOf("Low", "Medium", "High"), 1)

        section("Photo & video")
        switchRow("Auto HDR", "HDR effect on photos in Photo / Portrait / Night", "hdr", true)
        choiceRow("Colour filter (default: Vivid)", "filter", Filters.all.map { it.name }, 1)
        switchRow("Colour look in video", "Bake the selected filter into recorded videos (takes a moment after recording)", "vlook", true)
        switchRow("AI enhance", "Automatic tone and clarity correction on saved photos", "ai", false)
        choiceRow("Video resolution", "vq", listOf("720p HD", "1080p FHD", "4K UHD (if supported)"), 1)
        choiceRow("Video frame rate", "vfps", listOf("30 fps", "60 fps (if supported)"), 0)

        section("Interface")
        choiceRow(
            "Camera theme colour", "theme", ThemeColors.names, 1,
            ThemeColors.names.indices.map { ThemeColors.colorFor(this, it) }
        )
        inputRow("Custom colour (hex)", "themehex", "Example: #FF5722. Used when \"Custom colour\" is chosen above")

        section("Other")
        actionRow("Reset settings") {
            prefs.edit().clear().apply()
            Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show()
            build()
        }
        root.addView(TextView(this).apply {
            text = "OpenCam"
            setTextColor(Color.GRAY)
            textSize = 12f
            setPadding(0, dp(24), 0, 0)
        })
    }

    private fun section(t: String) {
        root.addView(TextView(this).apply {
            text = t
            setTextColor(Color.parseColor("#FFCC00"))
            textSize = 13f
            setPadding(0, dp(22), 0, dp(4))
        })
    }

    private fun row(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(12), 0, dp(12))
    }

    private fun texts(title: String, sub: String?, dim: Boolean = false): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = title
            setTextColor(if (dim) Color.GRAY else Color.WHITE)
            textSize = 16f
        })
        if (sub != null) col.addView(TextView(this).apply {
            text = sub
            setTextColor(Color.GRAY)
            textSize = 12f
        })
        return col
    }

    private fun switchRow(title: String, sub: String?, key: String, def: Boolean) {
        val r = row()
        r.addView(texts(title, sub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(this).apply {
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        root.addView(r)
    }

    private fun choiceRow(title: String, key: String, options: List<String>, def: Int, swatches: List<Int>? = null) {
        val r = row()
        r.addView(texts(title, null), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = TextView(this).apply {
            text = options[prefs.getInt(key, def).coerceIn(0, options.size - 1)]
            setTextColor(Color.GRAY)
            textSize = 14f
            maxWidth = dp(170)
            gravity = Gravity.END
        }
        r.addView(v)
        r.setOnClickListener {
            val cur = prefs.getInt(key, def).coerceIn(0, options.size - 1)
            GlassDialog.choice(this, title, options, cur, r, null, swatches) { which ->
                prefs.edit().putInt(key, which).apply()
                v.text = options[which]
            }
        }
        root.addView(r)
    }

    private fun inputRow(title: String, key: String, sub: String) {
        val r = row()
        r.addView(texts(title, sub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = TextView(this).apply {
            text = prefs.getString(key, "").orEmpty().ifBlank { "Not set" }
            setTextColor(Color.GRAY)
            textSize = 14f
            maxWidth = dp(150)
            maxLines = 1
        }
        r.addView(v)
        r.setOnClickListener {
            GlassDialog.input(this, title, prefs.getString(key, "").orEmpty(), r) { text ->
                prefs.edit().putString(key, text).apply()
                v.text = text.ifBlank { "Not set" }
            }
        }
        root.addView(r)
    }

    private fun infoRow(title: String, sub: String) {
        val r = row()
        r.addView(texts(title, sub, true))
        root.addView(r)
    }

    private fun actionRow(title: String, onClick: () -> Unit) {
        val r = row()
        r.addView(texts(title, null))
        r.setOnClickListener(View.OnClickListener { onClick() })
        root.addView(r)
    }
}
