package com.opencam.camera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log2
import kotlin.math.pow

/**
 * Arc-shaped zoom dial. Drag left/right to rotate the dial; zoom changes
 * logarithmically (each major tick is one doubling of zoom).
 */
class ZoomDialView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var minZoom = 1f
    var maxZoom = 10f

    var zoom = 1f
        set(value) {
            field = value.coerceIn(minZoom, maxZoom)
            invalidate()
        }

    var onZoomChanged: ((Float) -> Unit)? = null
    var onInteraction: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val degPerOctave = 30f
    private var lastX = 0f

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2f * d
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 12f * d
        textAlign = Paint.Align.CENTER
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5C518")
        textSize = 20f * d
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5C518")
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 3f * d
    }

    private val labelValues = floatArrayOf(0.6f, 1f, 2f, 3f, 5f, 10f, 20f, 30f, 60f, 100f)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val radius = w * 0.95f
        val cx = w / 2f
        val cy = h * 0.55f + radius
        val curLog = log2(zoom)

        // Ticks (every 0.1 octave)
        val kMin = floor(log2(minZoom) * 10f).toInt()
        val kMax = ceil(log2(maxZoom) * 10f).toInt()
        for (k in kMin..kMax) {
            val lg = k / 10f
            val deg = (lg - curLog) * degPerOctave
            if (abs(deg) > 52f) continue
            val major = k % 10 == 0
            val len = (if (major) 20f else 11f) * d
            tickPaint.alpha = (255 * (1f - abs(deg) / 60f)).toInt().coerceIn(40, 255)
            canvas.save()
            canvas.rotate(deg, cx, cy)
            canvas.drawLine(cx, cy - radius, cx, cy - radius + len, tickPaint)
            canvas.restore()
        }

        // Labels
        for (v in labelValues) {
            if (v < minZoom - 0.01f || v > maxZoom + 0.01f) continue
            val deg = (log2(v) - curLog) * degPerOctave
            if (abs(deg) > 48f) continue
            labelPaint.alpha = (255 * (1f - abs(deg) / 60f)).toInt().coerceIn(60, 255)
            canvas.save()
            canvas.rotate(deg, cx, cy)
            val text = if (v < 1f) "%.1f".format(v) else "%d".format(v.toInt())
            canvas.drawText(text, cx, cy - radius + 40f * d, labelPaint)
            canvas.restore()
        }

        // Fixed centre marker + value
        canvas.drawLine(cx, cy - radius - 6f * d, cx, cy - radius + 26f * d, centerPaint)
        canvas.drawText("%.1fx".format(zoom), cx, h * 0.38f, valuePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                parent?.requestDisallowInterceptTouchEvent(true)
                onInteraction?.invoke()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastX
                lastX = event.x
                val pxPerOctave = width * 0.30f
                val newLog = log2(zoom) - dx / pxPerOctave
                zoom = 2f.pow(newLog)
                onZoomChanged?.invoke(zoom)
                onInteraction?.invoke()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                onInteraction?.invoke()
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
