package com.opencam.camera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Camera zoom dial (big translucent disc, ticks on the rim, pointing inward).
 * Drag sideways to rotate the wheel; the yellow tick at the top is the current zoom.
 *
 * All sizes are defined for a 1080px wide reference and scaled with the view width,
 * so it looks the same on every phone.
 */
class ZoomDialView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    var minZoom = 1f
    var maxZoom = 8f
    var zoom = 1f
        set(v) {
            field = v
            invalidate()
        }
    var onZoomChanged: ((Float) -> Unit)? = null
    var onInteraction: (() -> Unit)? = null
    var dragging = false

    /** Leica-style tick sound while turning the dial (toggle in Settings). */
    var soundOn = true
    /** 0.3 = low, 0.6 = medium, 1.0 = high */
    var soundVol = 0.6f
    private var tickPool: SoundPool? = null
    private var tickId = 0
    private var tickReady = false
    private var lastTickKey = Int.MIN_VALUE
    private var lastTickMs = 0L

    private fun ensurePool() {
        if (tickPool != null) return
        val sp = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        sp.setOnLoadCompleteListener { _, _, st -> tickReady = st == 0 }
        tickId = sp.load(context, R.raw.zoom_tick, 1)
        tickPool = sp
    }

    /** Index of the tick the zoom value currently sits on (same spacing as drawn ticks). */
    private fun tickKey(z: Float): Int = when {
        z < 10f -> (z / 0.1f).roundToInt()
        z < 20f -> 100 + ((z - 10f) / 0.5f).roundToInt()
        else -> 120 + (z - 20f).roundToInt()
    }

    private fun playTick(z: Float) {
        if (!soundOn) return
        val key = tickKey(z)
        if (key == lastTickKey) return
        lastTickKey = key
        val now = System.currentTimeMillis()
        if (now - lastTickMs < 22) return
        lastTickMs = now
        ensurePool()
        if (!tickReady) return
        val major = majors.any { abs(it - z) < 0.06f }
        val v = soundVol * (if (major) 1f else 0.7f)
        tickPool?.play(tickId, v, v, 1, 0, if (major) 0.85f else 1f)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        tickPool?.release()
        tickPool = null
        tickReady = false
    }

    /** Zoom values that get a long white tick + number. Remove 3.2f if your phone has no such lens. */
    var majors = floatArrayOf(0.6f, 1f, 2f, 5f, 10f, 20f, 30f)

    // ---- reference geometry (px @ 1080 wide) ----
    private val refDiscR = 650f
    private val refInset = 10f
    private val refMajLen = 35f
    private val refMinLen = 25f
    private val refPtrLen = 37f
    private val refMajW = 4f
    private val refMinW = 2.4f
    private val refPtrW = 6.5f
    private val refLabelDrop = 82f
    private val refText = 28f

    private val kDeg = 52f            // degrees of rotation per ln(zoom)
    private val visibleDeg = 58f      // ticks beyond this angle are off screen
    private val dragGain = 1.2f

    private val d = resources.displayMetrics.density
    private var scale = 1f
    private var accent = Color.parseColor("#FFB300")

    private val disc = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(100, 0, 0, 0) }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(26, 255, 255, 255)
        style = Paint.Style.STROKE
    }
    private val minorTick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(95, 255, 255, 255)
        strokeCap = Paint.Cap.ROUND
    }
    private val majorTick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
    }
    private val pointer = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        strokeCap = Paint.Cap.ROUND
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }
    private val cur = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private var lastX = 0f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        scale = w / 1080f
        rim.strokeWidth = 3f * scale
        // dark translucent disc (hardware accelerated, no shadow layers -> smooth drag)
        disc.shader = android.graphics.LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(135, 0, 0, 0), Color.argb(115, 0, 0, 0),
            android.graphics.Shader.TileMode.CLAMP
        )
        minorTick.strokeWidth = refMinW * scale
        majorTick.strokeWidth = refMajW * scale
        pointer.strokeWidth = refPtrW * scale
        label.textSize = refText * scale
        cur.textSize = refText * scale
    }

    private fun round2(v: Float) = (v * 100f).roundToInt() / 100f

    /** Calls f for every tick value in [lo, hi]: 0.1 steps below 10x, 0.5 up to 20x, then 1.0. */
    private fun forTicks(lo: Float, hi: Float, f: (Float) -> Unit) {
        fun seg(a: Float, b: Float, st: Float) {
            val from = max(lo, a)
            val to = min(hi, b)
            if (from > to) return
            var i = ceil(from / st - 1e-3f).toInt()
            val end = floor(to / st + 1e-3f).toInt()
            while (i <= end) {
                val v = i * st
                if (v < b - 1e-3f) f(round2(v))
                i++
            }
        }
        seg(0.1f, 10f, 0.1f)
        seg(10f, 20f, 0.5f)
        seg(20f, 1000f, 1f)
    }

    private fun fmt(v: Float): String =
        if (abs(v - v.roundToInt()) < 0.001f) v.roundToInt().toString()
        else String.format(java.util.Locale.US, "%.1f", v)

    override fun onDraw(c: Canvas) {
        if (width == 0) return
        val s = scale
        val r = refDiscR * s
        val top = 14f * d
        val cx = width / 2f
        val cy = top + r
        val r0 = r - refInset * s                 // radius where ticks start (outer end)
        val rLabel = r0 - refLabelDrop * s        // radius of label centres

        // disc
        c.drawCircle(cx, cy, r, disc)
        c.drawCircle(cx, cy, r - 1.5f * s, rim)

        val lnCur = ln(zoom)
        val span = visibleDeg / kDeg
        val lo = max(minZoom, exp(lnCur - span))
        val hi = min(maxZoom, exp(lnCur + span))
        val fm = label.fontMetrics
        val textShift = (fm.ascent + fm.descent) / 2f

        forTicks(lo, hi) { v ->
            val deg = (ln(v) - lnCur) * kDeg
            val a = Math.toRadians(deg.toDouble())
            val sn = sin(a).toFloat()
            val cs = cos(a).toFloat()
            val isMajor = majors.any { abs(it - v) < 0.005f }
            val len = (if (isMajor) refMajLen else refMinLen) * s
            c.drawLine(
                cx + r0 * sn, cy - r0 * cs,
                cx + (r0 - len) * sn, cy - (r0 - len) * cs,
                if (isMajor) majorTick else minorTick
            )
            if (isMajor) {
                val dist = abs(deg)
                if (dist > 5f) {
                    // labels near the pointer fade out so they never collide with the yellow value
                    val t = ((dist - 5f) / 7f).coerceIn(0f, 1f)
                    label.alpha = (255 * (0.3f + 0.7f * t)).toInt()
                    c.drawText(fmt(v), cx + rLabel * sn, cy - rLabel * cs - textShift, label)
                }
            }
        }

        // current value pointer + text
        c.drawLine(cx, cy - r0, cx, cy - r0 + refPtrLen * s, pointer)
        c.drawText(
            String.format(java.util.Locale.US, "%.1f\u00D7", zoom),
            cx, cy - rLabel - textShift, cur
        )
    }

    fun setAccent(col: Int) {
        accent = col
        cur.color = col
        pointer.color = col
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                lastX = e.x
                lastTickKey = tickKey(zoom)
                onInteraction?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                val r = refDiscR * scale
                val dx = e.x - lastX
                lastX = e.x
                val dDeg = -dx / r * (180f / Math.PI.toFloat()) * dragGain
                val nz = exp(ln(zoom) + dDeg / kDeg).coerceIn(minZoom, maxZoom)
                zoom = nz
                playTick(nz)
                onZoomChanged?.invoke(nz)
                onInteraction?.invoke()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                onInteraction?.invoke()
            }
        }
        return true
    }
}
