package com.opencam.camera

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

/**
 * Sends a photo to the Gemini API (image-editing model) and returns the enhanced result.
 * The API key and model id come from the app settings and are stored only on the phone.
 */
object GeminiEnhancer {

    const val DEFAULT_MODEL = "gemini-2.5-flash-image"

    const val DEFAULT_PROMPT =
        "Enhance this photograph so it looks like it was shot with a flagship phone camera: " +
            "improve exposure and dynamic range, recover shadows and highlights, correct white " +
            "balance, make colors natural and vibrant, reduce noise and add fine detail and " +
            "sharpness. Keep the exact same composition, framing, people, faces, expressions, " +
            "skin tones and objects. Do not add, remove or change anything in the scene. " +
            "Do not add text or watermarks. Output a photorealistic photo."

    class Result(val bitmap: Bitmap?, val error: String?)

    /** Downscales to at most [maxSide] px and encodes as JPEG, to keep the upload small. */
    fun toJpegBytes(src: Bitmap, maxSide: Int = 1536): ByteArray {
        val longest = max(src.width, src.height)
        val scaled = if (longest > maxSide) {
            val s = maxSide.toFloat() / longest
            Bitmap.createScaledBitmap(
                src, max(1, (src.width * s).toInt()), max(1, (src.height * s).toInt()), true
            )
        } else src
        val bos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 90, bos)
        if (scaled !== src) scaled.recycle()
        return bos.toByteArray()
    }

    fun enhance(jpeg: ByteArray, apiKey: String, model: String, prompt: String): Result {
        var conn: HttpURLConnection? = null
        try {
            val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
            val parts = JSONArray()
                .put(JSONObject().put("text", prompt))
                .put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", b64)
                    )
                )
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            // Older image models need the output type to be requested explicitly.
            if (model.contains("2.0")) {
                body.put(
                    "generationConfig",
                    JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE"))
                )
            }

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 20_000
            conn.readTimeout = 150_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                return Result(null, httpError(code, text))
            }
            return parse(text)
        } catch (e: java.net.UnknownHostException) {
            return Result(null, "No internet connection")
        } catch (e: java.net.SocketTimeoutException) {
            return Result(null, "Request timed out")
        } catch (t: Throwable) {
            return Result(null, t.message ?: t.javaClass.simpleName)
        } finally {
            conn?.disconnect()
        }
    }

    private fun httpError(code: Int, text: String): String {
        val msg = try {
            JSONObject(text).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: Exception) {
            ""
        }
        val hint = when (code) {
            400 -> "Bad request (check model id / API key)"
            401, 403 -> "API key rejected or not allowed"
            404 -> "Model not found (check model id in Settings)"
            429 -> "Quota or rate limit reached (enable billing or wait)"
            else -> "Server error"
        }
        return "HTTP $code: $hint" + if (msg.isNotEmpty()) "\n" + msg.take(200) else ""
    }

    private fun parse(text: String): Result {
        val json = JSONObject(text)
        val cands = json.optJSONArray("candidates")
        val textParts = StringBuilder()
        if (cands != null && cands.length() > 0) {
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val inline = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
                    val data = inline?.optString("data").orEmpty()
                    if (data.isNotEmpty()) {
                        val bytes = Base64.decode(data, Base64.DEFAULT)
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) return Result(bmp, null)
                    }
                    p.optString("text").takeIf { it.isNotEmpty() }?.let { textParts.append(it) }
                }
            }
        }
        val block = json.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
        val msg = when {
            block.isNotEmpty() -> "Blocked by Gemini: $block"
            textParts.isNotEmpty() -> "No image returned: " + textParts.toString().take(160)
            else -> "No image returned"
        }
        return Result(null, msg)
    }
}
