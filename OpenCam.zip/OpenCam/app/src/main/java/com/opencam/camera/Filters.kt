package com.opencam.camera

import android.graphics.ColorMatrix

/** Colour filters shared by the live preview and the saved photo. */
object Filters {

    data class Def(val name: String, val matrix: ColorMatrix?)

    private fun sat(s: Float) = ColorMatrix().apply { setSaturation(s) }

    private fun contrast(c: Float): ColorMatrix {
        val t = (1f - c) * 128f
        return ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    fun bright(b: Float) = ColorMatrix(
        floatArrayOf(
            1f, 0f, 0f, 0f, b,
            0f, 1f, 0f, 0f, b,
            0f, 0f, 1f, 0f, b,
            0f, 0f, 0f, 1f, 0f
        )
    )

    private fun scale(r: Float, g: Float, b: Float) = ColorMatrix(
        floatArrayOf(
            r, 0f, 0f, 0f, 0f,
            0f, g, 0f, 0f, 0f,
            0f, 0f, b, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    )

    private val sepia = ColorMatrix(
        floatArrayOf(
            0.393f, 0.769f, 0.189f, 0f, 0f,
            0.349f, 0.686f, 0.168f, 0f, 0f,
            0.272f, 0.534f, 0.131f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    )

    private fun chain(vararg ms: ColorMatrix): ColorMatrix {
        val out = ColorMatrix()
        for (m in ms) out.postConcat(m)
        return out
    }

    val all: List<Def> = listOf(
        Def("Original", null),
        Def("Vivid", chain(sat(1.45f), contrast(1.1f))),
        Def("Fresh", chain(sat(1.15f), bright(12f), scale(0.98f, 1.04f, 1.02f))),
        Def("Warm", chain(scale(1.1f, 1.02f, 0.88f), sat(1.1f))),
        Def("Cool", chain(scale(0.9f, 1f, 1.12f), sat(1.05f))),
        Def("Soft", chain(sat(0.9f), contrast(0.9f), bright(14f))),
        Def("Film", chain(sat(0.8f), contrast(1.12f), scale(1.04f, 1f, 0.94f), bright(-4f))),
        Def("Vintage", chain(sepia, contrast(0.95f), bright(6f))),
        Def("Sunset", chain(scale(1.15f, 0.95f, 0.8f), sat(1.2f))),
        Def("Mono", sat(0f)),
        Def("Noir", chain(sat(0f), contrast(1.35f), bright(-10f)))
    )

    /** Simple colour parameters used to bake a filter into recorded video (approximates the photo matrix). */
    class Look(
        val sat: Float = 1f, val contrast: Float = 1f, val bright: Float = 0f,
        val r: Float = 1f, val g: Float = 1f, val b: Float = 1f
    )

    /** Same order as [all]. */
    private val looks: List<Look?> = listOf(
        null,
        Look(sat = 1.45f, contrast = 1.1f),                                   // Vivid
        Look(sat = 1.15f, bright = 12f, r = 0.98f, g = 1.04f, b = 1.02f),    // Fresh
        Look(sat = 1.1f, r = 1.1f, g = 1.02f, b = 0.88f),                     // Warm
        Look(sat = 1.05f, r = 0.9f, b = 1.12f),                               // Cool
        Look(sat = 0.9f, contrast = 0.9f, bright = 14f),                      // Soft
        Look(sat = 0.8f, contrast = 1.12f, bright = -4f, r = 1.04f, b = 0.94f), // Film
        Look(sat = 0.45f, contrast = 0.95f, bright = 6f, r = 1.08f, b = 0.86f), // Vintage
        Look(sat = 1.2f, r = 1.15f, g = 0.95f, b = 0.8f),                     // Sunset
        Look(sat = 0f),                                                       // Mono
        Look(sat = 0f, contrast = 1.35f, bright = -10f)                       // Noir
    )

    fun lookFor(index: Int): Look? = looks.getOrNull(index)
}
