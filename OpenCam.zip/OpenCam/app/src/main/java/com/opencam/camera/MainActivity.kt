package com.opencam.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.camera2.CaptureRequest
import android.media.MediaActionSound
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import android.hardware.camera2.CameraCharacteristics
import android.util.Range
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.ZoomState
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

@OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    private enum class Mode(val label: String) {
        PRO("PRO"), VIDEO("VIDEO"), PHOTO("PHOTO"), PORTRAIT("PORTRAIT"), NIGHT("NIGHT")
    }

    private enum class Ratio { R11, R43, R169, FULL }

    private enum class Panel { NONE, FILTERS, BEAUTY, PRO, EV }

    private class SimpleSeek(
        val onChange: (Int, Boolean) -> Unit,
        val onStop: () -> Unit = {}
    ) : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) =
            onChange(progress, fromUser)

        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) = onStop()
    }

    companion object {
        private val SHUTTER_DEN = intArrayOf(4000, 2000, 1000, 500, 250, 125, 60, 30, 15, 8, 4)
        private val INTERVALS = intArrayOf(1, 2, 3, 5)
    }

    // accent colour (Settings > Camera theme colour)
    private var YELLOW = Color.parseColor("#FFCC00")
    private var settingsReady = false

    // ---- views ----
    private lateinit var root: FrameLayout
    private lateinit var previewContainer: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var gridOverlay: GridOverlayView
    private lateinit var focusRing: View
    private lateinit var tvRec: TextView
    private lateinit var tvCountdown: TextView
    private lateinit var flashOverlay: View
    private lateinit var topBar: LinearLayout
    private lateinit var btnFlash: ImageView
    private lateinit var btnEv: ImageView
    private lateinit var btnTimer: ImageView
    private lateinit var btnAiTop: ImageView
    private lateinit var btnMenu: ImageView
    private lateinit var overlayArea: FrameLayout
    private lateinit var zoomRow: LinearLayout
    private lateinit var pill: LinearLayout
    private lateinit var tvPill: TextView
    private lateinit var sideCol: LinearLayout
    private lateinit var btnAi: ImageView
    private lateinit var btnFilters: ImageView
    private lateinit var btnBeauty: ImageView
    private lateinit var zoomDial: ZoomDialView
    private lateinit var filterStrip: HorizontalScrollView
    private lateinit var filterRow: LinearLayout
    private lateinit var beautyPanel: LinearLayout
    private lateinit var tvBeauty: TextView
    private lateinit var seekBeauty: SeekBar
    private lateinit var evPanel: LinearLayout
    private lateinit var tvEv2: TextView
    private lateinit var seekEv2: SeekBar
    private lateinit var proPanel: LinearLayout
    private lateinit var tvEv: TextView
    private lateinit var seekEv: SeekBar
    private lateinit var swManual: SwitchCompat
    private lateinit var tvIso: TextView
    private lateinit var seekIso: SeekBar
    private lateinit var tvShutter: TextView
    private lateinit var seekShutter: SeekBar
    private lateinit var modeScroll: HorizontalScrollView
    private lateinit var modeRow: LinearLayout
    private lateinit var thumb: ImageView
    private lateinit var shutter: FrameLayout
    private lateinit var shutterInner: View
    private lateinit var btnFlip: ImageView

    // menu panel
    private lateinit var menuPanel: LinearLayout
    private lateinit var btnMenuClose: ImageView
    private lateinit var rowRatio: LinearLayout
    private lateinit var rowTimer: LinearLayout
    private lateinit var ratioViews: List<TextView>
    private lateinit var timerViews: List<TextView>
    private lateinit var colHdr: View
    private lateinit var colWm: View
    private lateinit var colInt: View
    private lateinit var tileHdr: TextView
    private lateinit var tileWm: View
    private lateinit var icWm: ImageView
    private lateinit var tileInt: View
    private lateinit var icInt: ImageView
    private lateinit var tvIntLabel: TextView
    private lateinit var tileSet: View

    // ---- state ----
    private lateinit var prefs: SharedPreferences
    private lateinit var cameraExecutor: ExecutorService
    private val main = Handler(Looper.getMainLooper())
    private val sound by lazy { MediaActionSound() }

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var zoomLive: LiveData<ZoomState>? = null

    private var lensFront = false
    private var ratio = Ratio.R43
    private var mode = Mode.PHOTO
    private var panel = Panel.NONE
    private var menuOpen = false
    private var flashMode = 0 // 0 auto, 1 on, 2 off
    private var timerSeconds = 0
    private var filterIndex = 1 // Vivid by default
    private var videoLook = true
    private var processingVideo = false
    private var beauty = 0
    private var autoHdr = true
    private var watermarkOn = false
    private var aiEnhance = false
    private var intervalEnabled = false
    private var intervalSec = 1
    private var intervalRunning = false
    private var manualExposure = false
    private var proIso = 400
    private var proShutterIndex = 6
    private var userEv = 0
    private var evLower = 0
    private var evUpper = 0
    private var evStep = 0f
    private var lastUri: Uri? = null
    private var countDown: CountDownTimer? = null
    private var dialVisible = false
    private var previewAspect = 0f
    private var containerBottom = 0

    // settings
    private var gridOn = false
    private var shutterSound = true
    private var mirrorSelfie = true
    private var volumeShutter = true
    private var videoQ = 1 // 0 HD, 1 FHD, 2 UHD
    private var videoFps = 0 // 0 = 30 fps, 1 = 60 fps
    private lateinit var videoChip: TextView
    private lateinit var videoPanel: LinearLayout
    private val resViews = ArrayList<TextView>()
    private val fpsViews = ArrayList<TextView>()

    private val modeViews = LinkedHashMap<Mode, TextView>()
    private val filterViews = ArrayList<TextView>()
    private val chips = ArrayList<Pair<Float, TextView>>()
    private var chipKey = ""

    private val hideDial = Runnable { hideDialNow() }
    private val hideFocus = Runnable { focusRing.visibility = View.GONE }
    private val intervalRunnable = Runnable { intervalTick() }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasCameraPermission()) startCamera()
            else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
        }

    private val zoomObserver = Observer<ZoomState> { zs ->
        zoomDial.minZoom = zs.minZoomRatio
        zoomDial.maxZoom = zs.maxZoomRatio
        if (!zoomDial.dragging) zoomDial.zoom = zs.zoomRatio
        updateZoomChips(zs.zoomRatio, zs.minZoomRatio, zs.maxZoomRatio)
    }

    // ------------------------------------------------------------------ lifecycle

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("opencam", MODE_PRIVATE)
        cameraExecutor = Executors.newSingleThreadExecutor()

        bindViews()
        loadPrefs()
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER

        buildModeStrip()
        buildVideoCfg()
        buildFilterStrip()
        setupListeners()
        applyModeUi()
        applyGrid()
        updateTopIcons()
        updateMenuUi()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    menuOpen -> closeMenu()
                    panel != Panel.NONE && !(mode == Mode.PRO && panel == Panel.PRO) -> {
                        panel = if (mode == Mode.PRO) Panel.PRO else Panel.NONE
                        refreshPanels()
                    }
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        prefs.getString("last_uri", null)?.let { lastUri = Uri.parse(it) }
        refreshThumb()

        if (hasCameraPermission()) startCamera()
        else permissionLauncher.launch(requiredPermissions())
    }

    override fun onDestroy() {
        super.onDestroy()
        countDown?.cancel()
        main.removeCallbacksAndMessages(null)
        cameraExecutor.shutdown()
    }

    override fun onPause() {
        super.onPause()
        if (intervalRunning) stopInterval()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (volumeShutter && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (event?.repeatCount == 0) shutter.performClick()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------------ setup

    private fun bindViews() {
        root = findViewById(R.id.root)
        previewContainer = findViewById(R.id.previewContainer)
        previewView = findViewById(R.id.previewView)
        gridOverlay = findViewById(R.id.gridOverlay)
        focusRing = findViewById(R.id.focusRing)
        tvRec = findViewById(R.id.tvRec)
        tvCountdown = findViewById(R.id.tvCountdown)
        flashOverlay = findViewById(R.id.flashOverlay)
        topBar = findViewById(R.id.topBar)
        btnFlash = findViewById(R.id.btnFlash)
        btnEv = findViewById(R.id.btnEv)
        btnTimer = findViewById(R.id.btnTimer)
        btnAiTop = findViewById(R.id.btnAiTop)
        btnMenu = findViewById(R.id.btnMenu)
        overlayArea = findViewById(R.id.overlayArea)
        zoomRow = findViewById(R.id.zoomRow)
        pill = findViewById(R.id.pill)
        tvPill = findViewById(R.id.tvPill)
        sideCol = findViewById(R.id.sideCol)
        btnAi = findViewById(R.id.btnAi)
        btnFilters = findViewById(R.id.btnFilters)
        btnBeauty = findViewById(R.id.btnBeauty)
        zoomDial = findViewById(R.id.zoomDial)
        filterStrip = findViewById(R.id.filterStrip)
        filterRow = findViewById(R.id.filterRow)
        beautyPanel = findViewById(R.id.beautyPanel)
        tvBeauty = findViewById(R.id.tvBeauty)
        seekBeauty = findViewById(R.id.seekBeauty)
        evPanel = findViewById(R.id.evPanel)
        tvEv2 = findViewById(R.id.tvEv2)
        seekEv2 = findViewById(R.id.seekEv2)
        proPanel = findViewById(R.id.proPanel)
        tvEv = findViewById(R.id.tvEv)
        seekEv = findViewById(R.id.seekEv)
        swManual = findViewById(R.id.swManual)
        tvIso = findViewById(R.id.tvIso)
        seekIso = findViewById(R.id.seekIso)
        tvShutter = findViewById(R.id.tvShutter)
        seekShutter = findViewById(R.id.seekShutter)
        modeScroll = findViewById(R.id.modeScroll)
        modeRow = findViewById(R.id.modeRow)
        thumb = findViewById(R.id.thumb)
        shutter = findViewById(R.id.shutter)
        shutterInner = findViewById(R.id.shutterInner)
        btnFlip = findViewById(R.id.btnFlip)

        menuPanel = findViewById(R.id.menuPanel)
        btnMenuClose = findViewById(R.id.btnMenuClose)
        rowRatio = findViewById(R.id.rowRatio)
        rowTimer = findViewById(R.id.rowTimer)
        ratioViews = listOf(
            findViewById(R.id.rat11), findViewById(R.id.rat43),
            findViewById(R.id.rat169), findViewById(R.id.ratFull)
        )
        timerViews = listOf(
            findViewById(R.id.tmOff), findViewById(R.id.tm3), findViewById(R.id.tm10)
        )
        colHdr = findViewById(R.id.colHdr)
        colWm = findViewById(R.id.colWm)
        colInt = findViewById(R.id.colInt)
        tileHdr = findViewById(R.id.tileHdr)
        tileWm = findViewById(R.id.tileWm)
        icWm = findViewById(R.id.icWm)
        tileInt = findViewById(R.id.tileInt)
        icInt = findViewById(R.id.icInt)
        tvIntLabel = findViewById(R.id.tvIntLabel)
        tileSet = findViewById(R.id.tileSet)
    }

    // ---- video quality / fps chip (ColorOS style): tap the chip, pick resolution and frame rate
    private fun buildVideoCfg() {
        videoChip = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setBackgroundResource(R.drawable.bg_pill)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            visibility = View.GONE
            setOnClickListener {
                if (recording != null) return@setOnClickListener
                videoPanel.visibility = if (videoPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                updateVideoCfg()
            }
        }
        videoPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            visibility = View.GONE
        }
        fun row(labels: List<String>, views: ArrayList<TextView>, onPick: (Int) -> Unit) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            labels.forEachIndexed { i, t ->
                val tv = TextView(this).apply {
                    text = t
                    textSize = 15f
                    gravity = android.view.Gravity.CENTER
                    setPadding(dp(14), dp(10), dp(14), dp(10))
                    setOnClickListener { onPick(i) }
                }
                views.add(tv)
                r.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            videoPanel.addView(r)
        }
        row(listOf("720P", "1080P", "4K"), resViews) { i ->
            videoQ = i
            prefs.edit().putInt("vq", videoQ).apply()
            videoCfgChanged()
        }
        row(listOf("30 fps", "60 fps"), fpsViews) { i ->
            videoFps = i
            prefs.edit().putInt("vfps", videoFps).apply()
            videoCfgChanged()
        }
        overlayArea.addView(videoChip, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL
        ).apply { topMargin = dp(10) })
        overlayArea.addView(videoPanel, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL
        ).apply { topMargin = dp(52) })
    }

    private fun videoCfgChanged() {
        updateVideoCfg()
        if (mode == Mode.VIDEO && recording == null) bindCamera()
    }

    private fun updateVideoCfg() {
        if (!::videoChip.isInitialized) return
        val q = when (videoQ) { 0 -> "720P"; 2 -> "4K"; else -> "1080P" }
        videoChip.text = "$q  \u00B7  ${if (videoFps == 1) 60 else 30}"
        videoChip.setTextColor(if (videoPanel.visibility == View.VISIBLE) YELLOW else Color.WHITE)
        resViews.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == videoQ) YELLOW else Color.WHITE)
            tv.typeface = if (i == videoQ) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        fpsViews.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == videoFps) YELLOW else Color.WHITE)
            tv.typeface = if (i == videoFps) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    /** Picks an AE target fps range from what the camera reports (exact fps,fps first). */
    private fun pickFpsRange(selector: CameraSelector, fps: Int): Range<Int>? {
        return try {
            val info = selector.filter(cameraProvider!!.availableCameraInfos).firstOrNull() ?: return null
            val ranges = Camera2CameraInfo.from(info)
                .getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                ?: return null
            ranges.firstOrNull { it.lower == fps && it.upper == fps }
                ?: ranges.filter { it.upper == fps }.maxByOrNull { it.lower }
        } catch (e: Exception) {
            null
        }
    }

    private fun applyDialPrefs() {
        zoomDial.soundOn = prefs.getBoolean("zoomsound", true)
        zoomDial.soundVol = when (prefs.getInt("zoomvol", 1)) { 0 -> 0.3f; 2 -> 1f; else -> 0.6f }
        zoomDial.setAccent(YELLOW)
    }

    override fun onResume() {
        super.onResume()
        if (!settingsReady) return
        // pick up changes made in the Settings page
        if (ThemeColors.color(this) != YELLOW) {
            recreate()
            return
        }
        val oldRatio = ratio
        val oldQ = videoQ
        val oldFps = videoFps
        applyDialPrefs()
        gridOn = prefs.getBoolean("grid", false)
        shutterSound = prefs.getBoolean("sound", true)
        mirrorSelfie = prefs.getBoolean("mirror", true)
        volumeShutter = prefs.getBoolean("volume", true)
        videoQ = prefs.getInt("vq", 1)
        videoFps = prefs.getInt("vfps", 0).coerceIn(0, 1)
        ratio = Ratio.values()[prefs.getInt("ratio", 1).coerceIn(0, 3)]
        autoHdr = prefs.getBoolean("hdr", true)
        watermarkOn = prefs.getBoolean("wm", false)
        aiEnhance = prefs.getBoolean("ai", false)
        filterIndex = prefs.getInt("filter", 1).coerceIn(0, Filters.all.size - 1)
        videoLook = prefs.getBoolean("vlook", true)
        applyLiveFilter()
        updateVideoCfg()
        applyGrid()
        updateMenuUi()
        updateSideIcons()
        if (oldRatio != ratio) {
            updatePreviewLayout()
            bindCamera()
        } else if (mode == Mode.VIDEO && (oldQ != videoQ || oldFps != videoFps)) {
            bindCamera()
        }
    }

    private fun loadPrefs() {
        YELLOW = ThemeColors.color(this)
        applyDialPrefs()
        gridOn = prefs.getBoolean("grid", false)
        shutterSound = prefs.getBoolean("sound", true)
        mirrorSelfie = prefs.getBoolean("mirror", true)
        volumeShutter = prefs.getBoolean("volume", true)
        videoQ = prefs.getInt("vq", 1)
        videoFps = prefs.getInt("vfps", 0).coerceIn(0, 1)
        ratio = Ratio.values()[prefs.getInt("ratio", 1).coerceIn(0, 3)]
        autoHdr = prefs.getBoolean("hdr", true)
        watermarkOn = prefs.getBoolean("wm", false)
        aiEnhance = prefs.getBoolean("ai", false)
        intervalSec = prefs.getInt("interval", 1).let { if (it in INTERVALS) it else 1 }
        beauty = prefs.getInt("beauty", 0)
        filterIndex = prefs.getInt("filter", 1).coerceIn(0, Filters.all.size - 1)
        videoLook = prefs.getBoolean("vlook", true)
        seekBeauty.progress = beauty
        tvBeauty.text = "Beauty  $beauty"
        seekIso.progress = (proIso / 100) - 1
        seekShutter.progress = proShutterIndex
        tvIso.text = "ISO  $proIso"
        tvShutter.text = "Shutter  1/${SHUTTER_DEN[proShutterIndex]}"
        seekIso.isEnabled = false
        seekShutter.isEnabled = false
        settingsReady = true
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupListeners() {
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updatePreviewLayout() }

        // Pinch to zoom, tap to focus, swipe to change mode
        val scaleDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    val cam = camera ?: return true
                    val cur = cam.cameraInfo.zoomState.value?.zoomRatio ?: return true
                    cam.cameraControl.setZoomRatio(cur * detector.scaleFactor)
                    if (panel == Panel.NONE && !menuOpen) showDial()
                    return true
                }
            })
        val gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusAt(e.x, e.y)
                return true
            }

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float
            ): Boolean {
                if (abs(velocityX) > abs(velocityY) && abs(velocityX) > 900f) {
                    val modes = Mode.values()
                    val i = modes.indexOf(mode) + if (velocityX < 0) 1 else -1
                    if (i in modes.indices) setMode(modes[i])
                    return true
                }
                return false
            }
        })
        previewView.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) gestureDetector.onTouchEvent(ev)
            true
        }

        zoomDial.onZoomChanged = { z -> camera?.cameraControl?.setZoomRatio(z) }
        zoomDial.onInteraction = { scheduleHideDial() }

        shutter.setOnClickListener { onShutter() }

        btnFlip.setOnClickListener {
            if (recording != null || intervalRunning) return@setOnClickListener
            lensFront = !lensFront
            btnFlip.animate().rotationBy(180f).setDuration(300).start()
            bindCamera()
        }

        // top bar
        btnFlash.setOnClickListener {
            flashMode = if (mode == Mode.VIDEO) {
                if (flashMode == 1) 2 else 1
            } else (flashMode + 1) % 3
            updateTopIcons()
            applyFlash()
        }
        btnEv.setOnClickListener {
            if (mode == Mode.PRO) {
                panel = Panel.PRO
                refreshPanels()
            } else togglePanel(Panel.EV)
        }
        btnTimer.setOnClickListener {
            if (recording != null || countDown != null) return@setOnClickListener
            timerSeconds = when (timerSeconds) { 0 -> 3; 3 -> 10; else -> 0 }
            updateMenuUi()
            toast(if (timerSeconds == 0) "Timer off" else "Timer ${timerSeconds}s")
        }
        btnAiTop.setOnClickListener {
            aiEnhance = !aiEnhance
            prefs.edit().putBoolean("ai", aiEnhance).apply()
            updateSideIcons()
            toast(if (aiEnhance) "AI enhance on" else "AI enhance off")
        }
        btnMenu.setOnClickListener { openMenu() }
        btnMenuClose.setOnClickListener { closeMenu() }

        // side column
        btnAi.setOnClickListener {
            aiEnhance = !aiEnhance
            prefs.edit().putBoolean("ai", aiEnhance).apply()
            updateSideIcons()
            toast(if (aiEnhance) "AI enhance on" else "AI enhance off")
        }
        btnFilters.setOnClickListener { togglePanel(Panel.FILTERS) }
        btnBeauty.setOnClickListener { togglePanel(Panel.BEAUTY) }

        // interval pill
        pill.setOnClickListener {
            if (intervalRunning) return@setOnClickListener
            intervalEnabled = !intervalEnabled
            updatePill()
            updateMenuUi()
        }

        // menu panel
        ratioViews.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                if (recording != null) return@setOnClickListener
                ratio = Ratio.values()[i]
                prefs.edit().putInt("ratio", i).apply()
                updateMenuUi()
                updatePreviewLayout()
                bindCamera()
            }
        }
        val timerValues = intArrayOf(0, 3, 10)
        timerViews.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                timerSeconds = timerValues[i]
                updateMenuUi()
            }
        }
        tileHdr.setOnClickListener {
            autoHdr = !autoHdr
            prefs.edit().putBoolean("hdr", autoHdr).apply()
            updateMenuUi()
        }
        tileWm.setOnClickListener {
            watermarkOn = !watermarkOn
            prefs.edit().putBoolean("wm", watermarkOn).apply()
            updateMenuUi()
        }
        tileInt.setOnClickListener {
            if (!intervalEnabled) {
                intervalEnabled = true
            } else {
                val idx = INTERVALS.indexOf(intervalSec)
                if (idx == INTERVALS.size - 1) intervalEnabled = false
                else intervalSec = INTERVALS[idx + 1]
            }
            prefs.edit().putInt("interval", intervalSec).apply()
            updatePill()
            updateMenuUi()
        }
        tileSet.setOnClickListener {
            closeMenu()
            showSettings()
        }

        thumb.setOnClickListener {
            val u = lastUri ?: return@setOnClickListener
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(u, contentResolver.getType(u))
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } catch (e: Exception) {
                toast("No gallery app found")
            }
        }

        seekBeauty.setOnSeekBarChangeListener(SimpleSeek({ p, _ ->
            beauty = p
            tvBeauty.text = "Beauty  $p"
        }, {
            prefs.edit().putInt("beauty", beauty).apply()
            updateSideIcons()
        }))

        val evListener = SimpleSeek({ p, fromUser -> if (fromUser) setEv(p + evLower) })
        seekEv.setOnSeekBarChangeListener(evListener)
        seekEv2.setOnSeekBarChangeListener(evListener)

        seekIso.setOnSeekBarChangeListener(SimpleSeek({ p, _ ->
            proIso = (p + 1) * 100
            tvIso.text = "ISO  $proIso"
        }, { if (manualExposure) bindCamera() }))

        seekShutter.setOnSeekBarChangeListener(SimpleSeek({ p, _ ->
            proShutterIndex = p
            tvShutter.text = "Shutter  1/${SHUTTER_DEN[p]}"
        }, { if (manualExposure) bindCamera() }))

        swManual.setOnCheckedChangeListener { _, checked ->
            manualExposure = checked
            seekEv.isEnabled = !checked
            seekEv2.isEnabled = !checked
            seekIso.isEnabled = checked
            seekShutter.isEnabled = checked
            bindCamera()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildModeStrip() {
        val pad = max(0, resources.displayMetrics.widthPixels / 2 - dp(50))
        modeRow.setPadding(pad, 0, pad, 0)
        for (m in Mode.values()) {
            val tv = TextView(this).apply {
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(14), 0, dp(14), 0)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)
                ).apply {
                    marginStart = dp(3)
                    marginEnd = dp(3)
                    gravity = Gravity.CENTER_VERTICAL
                }
                setOnClickListener { setMode(m) }
            }
            modeRow.addView(tv)
            modeViews[m] = tv
        }
    }

    private fun buildFilterStrip() {
        Filters.all.forEachIndexed { i, f ->
            val tv = TextView(this).apply {
                text = f.name
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(4) }
                setOnClickListener {
                    filterIndex = i
                    prefs.edit().putInt("filter", i).apply()
                    updateFilterUi()
                    applyLiveFilter()
                }
            }
            filterRow.addView(tv)
            filterViews.add(tv)
        }
        updateFilterUi()
    }

    // ------------------------------------------------------------------ preview layout

    /**
     * Sizes the preview for the selected aspect ratio, based on the real screen size,
     * so the same layout fits any phone (tall 18.7:9 screens included).
     */
    private fun updatePreviewLayout() {
        val w = root.width - root.paddingLeft - root.paddingRight
        val h = root.height - root.paddingTop - root.paddingBottom
        if (w <= 0 || h <= 0) return
        val topH = dp(56)

        val top: Int
        val height: Int
        if (mode == Mode.VIDEO || ratio == Ratio.R169) {
            top = 0
            height = min(w * 16 / 9, h)
        } else if (ratio == Ratio.FULL) {
            top = 0
            height = h
        } else if (ratio == Ratio.R11) {
            top = topH
            height = min(w, h - topH)
        } else {
            top = topH
            height = min(w * 4 / 3, h - topH)
        }

        val lp = previewContainer.layoutParams as FrameLayout.LayoutParams
        if (lp.topMargin != top || lp.height != height) {
            lp.topMargin = top
            lp.height = height
            previewContainer.layoutParams = lp
        }
        topBar.setBackgroundColor(if (top == 0) Color.parseColor("#66000000") else Color.BLACK)
        previewAspect = w.toFloat() / height
        containerBottom = top + height

        // keep the in-preview widgets just above the bottom edge of the preview
        overlayArea.post {
            val pad = max(0, overlayArea.bottom - containerBottom)
            if (overlayArea.paddingBottom != pad) overlayArea.setPadding(0, 0, 0, pad)
        }
    }

    // ------------------------------------------------------------------ UI state

    private fun setMode(m: Mode) {
        if (recording != null || countDown != null || intervalRunning) return
        if (m == mode) {
            openMenu()
            return
        }
        mode = m
        panel = when {
            m == Mode.PRO -> Panel.PRO
            panel == Panel.PRO -> Panel.NONE
            m == Mode.VIDEO && (panel == Panel.FILTERS || panel == Panel.BEAUTY) -> Panel.NONE
            (m == Mode.NIGHT || m == Mode.PRO) && panel == Panel.BEAUTY -> Panel.NONE
            else -> panel
        }
        applyModeUi()
        updatePreviewLayout()
        bindCamera()
    }

    private fun applyModeUi() {
        for ((m, tv) in modeViews) {
            val sel = m == mode
            tv.text = if (sel) m.label + " ▴" else m.label
            tv.setTextColor(if (sel) YELLOW else Color.WHITE)
            tv.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            tv.setBackgroundResource(if (sel) R.drawable.bg_mode_sel else 0)
        }
        modeScroll.post {
            val v = modeViews[mode] ?: return@post
            modeScroll.smoothScrollTo(v.left + v.width / 2 - modeScroll.width / 2, 0)
        }
        val video = mode == Mode.VIDEO
        btnBeauty.visibility = if (mode == Mode.PHOTO || mode == Mode.PORTRAIT) View.VISIBLE else View.GONE
        btnFilters.visibility = if (video) View.GONE else View.VISIBLE
        btnAi.visibility = if (video) View.GONE else View.VISIBLE
        videoChip.visibility = if (video) View.VISIBLE else View.GONE
        if (!video) videoPanel.visibility = View.GONE
        updateVideoCfg()
        btnAiTop.alpha = if (video) 0.3f else 1f
        btnAiTop.isEnabled = !video
        btnTimer.alpha = if (video) 0.3f else 1f
        btnTimer.isEnabled = !video
        rowRatio.visibility = if (video) View.GONE else View.VISIBLE
        rowTimer.visibility = if (video) View.GONE else View.VISIBLE
        colHdr.visibility = if (video) View.GONE else View.VISIBLE
        colWm.visibility = if (video) View.GONE else View.VISIBLE
        colInt.visibility = if (video) View.GONE else View.VISIBLE
        updateShutterBg()
        updateTopIcons()
        updateSideIcons()
        updatePill()
        refreshPanels()
        applyLiveFilter()
    }

    private fun updateShutterBg() {
        shutterInner.setBackgroundResource(
            when {
                recording != null || intervalRunning -> R.drawable.shutter_inner_rec
                mode == Mode.VIDEO -> R.drawable.shutter_inner_video
                else -> R.drawable.shutter_inner_photo
            }
        )
    }

    private fun togglePanel(p: Panel) {
        panel = if (panel == p) (if (mode == Mode.PRO) Panel.PRO else Panel.NONE) else p
        hideDialNow()
        refreshPanels()
    }

    private fun refreshPanels() {
        val showFilters = panel == Panel.FILTERS && mode != Mode.VIDEO
        val showBeauty = panel == Panel.BEAUTY && (mode == Mode.PHOTO || mode == Mode.PORTRAIT)
        val showPro = panel == Panel.PRO && mode == Mode.PRO
        val showEv = panel == Panel.EV && mode != Mode.PRO
        filterStrip.visibility = if (showFilters) View.VISIBLE else View.GONE
        beautyPanel.visibility = if (showBeauty) View.VISIBLE else View.GONE
        proPanel.visibility = if (showPro) View.VISIBLE else View.GONE
        evPanel.visibility = if (showEv) View.VISIBLE else View.GONE
        val none = !showFilters && !showBeauty && !showPro && !showEv
        if (!none) {
            zoomDial.visibility = View.GONE
            dialVisible = false
        }
        zoomRow.visibility = if (none && !dialVisible) View.VISIBLE else View.INVISIBLE
        sideCol.visibility = if (none && !dialVisible && mode != Mode.VIDEO) View.VISIBLE else View.INVISIBLE
        pill.visibility = if (none && !dialVisible && mode != Mode.VIDEO) View.VISIBLE else View.GONE
        updateTopIcons()
        updateSideIcons()
    }

    private fun updateTopIcons() {
        btnFlash.setImageResource(
            when (flashMode) {
                0 -> R.drawable.ic_flash_auto
                1 -> R.drawable.ic_flash_on
                else -> R.drawable.ic_flash_off
            }
        )
        btnFlash.setColorFilter(if (flashMode == 1) YELLOW else Color.WHITE)
        btnTimer.setImageResource(if (timerSeconds > 0) R.drawable.ic_timer_on else R.drawable.ic_timer_off)
        btnTimer.setColorFilter(if (timerSeconds > 0) YELLOW else Color.WHITE)
        btnEv.setColorFilter(if (panel == Panel.EV || userEv != 0) YELLOW else Color.WHITE)
    }

    private fun updateSideIcons() {
        btnAi.setColorFilter(if (aiEnhance) YELLOW else Color.WHITE)
        btnAiTop.setColorFilter(if (aiEnhance) YELLOW else Color.WHITE)
        btnFilters.setColorFilter(if (filterIndex != 0 || panel == Panel.FILTERS) YELLOW else Color.WHITE)
        btnBeauty.setColorFilter(if (beauty > 0 || panel == Panel.BEAUTY) YELLOW else Color.WHITE)
    }

    private fun updateFilterUi() {
        filterViews.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == filterIndex) YELLOW else Color.WHITE)
            tv.typeface = if (i == filterIndex) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        updateSideIcons()
    }

    private fun updatePill() {
        tvPill.visibility = if (intervalEnabled) View.VISIBLE else View.GONE
        tvPill.text = "${intervalSec}s"
    }

    private fun updateMenuUi() {
        ratioViews.forEachIndexed { i, tv -> styleSeg(tv, i == ratio.ordinal) }
        val sel = when (timerSeconds) { 3 -> 1; 10 -> 2; else -> 0 }
        timerViews.forEachIndexed { i, tv -> styleSeg(tv, i == sel) }

        tileHdr.text = if (autoHdr) "HDR\nAUTO" else "HDR\nOFF"
        tileHdr.setBackgroundResource(if (autoHdr) R.drawable.bg_tile_on else R.drawable.bg_tile)
        tileHdr.setTextColor(if (autoHdr) Color.parseColor("#1A1A1A") else Color.WHITE)

        tileWm.setBackgroundResource(if (watermarkOn) R.drawable.bg_tile_on else R.drawable.bg_tile)
        icWm.setColorFilter(if (watermarkOn) Color.parseColor("#1A1A1A") else Color.WHITE)

        tileInt.setBackgroundResource(if (intervalEnabled) R.drawable.bg_tile_on else R.drawable.bg_tile)
        icInt.setColorFilter(if (intervalEnabled) Color.parseColor("#1A1A1A") else Color.WHITE)
        tvIntLabel.text = if (intervalEnabled) "Interval ${intervalSec}s" else "Interval shooting"
        updateTopIcons()
    }

    private fun styleSeg(tv: TextView, selected: Boolean) {
        tv.setTextColor(if (selected) YELLOW else Color.WHITE)
        tv.typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun openMenu() {
        if (recording != null || intervalRunning) return
        menuOpen = true
        hideDialNow()
        updateMenuUi()
        menuPanel.visibility = View.VISIBLE
    }

    private fun closeMenu() {
        menuOpen = false
        menuPanel.visibility = View.GONE
    }

    /** Applies the selected colour filter to the live preview. */
    private fun applyLiveFilter() {
        val cm = if (mode == Mode.VIDEO && !videoLook) null else Filters.all[filterIndex].matrix
        if (cm == null) {
            previewView.setLayerType(View.LAYER_TYPE_NONE, null)
        } else {
            val p = Paint()
            p.colorFilter = ColorMatrixColorFilter(cm)
            previewView.setLayerType(View.LAYER_TYPE_HARDWARE, p)
        }
    }

    private fun applyGrid() {
        gridOverlay.visibility = if (gridOn) View.VISIBLE else View.GONE
    }

    private fun applyFlash() {
        if (mode == Mode.VIDEO && flashMode == 0) flashMode = 2
        imageCapture?.flashMode = when (flashMode) {
            0 -> ImageCapture.FLASH_MODE_AUTO
            1 -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        camera?.cameraControl?.enableTorch(mode == Mode.VIDEO && flashMode == 1)
        updateTopIcons()
    }

    private fun fmt(v: Float): String =
        if (abs(v - Math.round(v)) < 0.05f) Math.round(v).toString() else "%.1f".format(v)

    private fun updateZoomChips(z: Float, minZ: Float, maxZ: Float) {
        val cand = floatArrayOf(0.6f, 1f, 2f, 5f).filter { it >= minZ - 0.01f && it <= maxZ + 0.01f }
        val key = cand.joinToString(",")
        if (key != chipKey) {
            chipKey = key
            zoomRow.removeAllViews()
            chips.clear()
            val size = dp(44)
            for (v in cand) {
                val tv = TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(size, size).apply {
                        marginStart = dp(6)
                        marginEnd = dp(6)
                    }
                    gravity = Gravity.CENTER
                    textSize = 13f
                    setOnClickListener { onChipClick(v) }
                    setOnLongClickListener { showDial(); true }
                }
                zoomRow.addView(tv)
                chips.add(v to tv)
            }
        }
        var selected = chips.firstOrNull()?.first
        for ((v, _) in chips) if (v <= z + 0.05f) selected = v
        for ((v, tv) in chips) {
            val isSel = v == selected
            tv.text = if (isSel) fmt(z) + "×" else fmt(v)
            tv.setTextColor(if (isSel) YELLOW else Color.WHITE)
            tv.setBackgroundResource(if (isSel) R.drawable.bg_chip else 0)
            tv.typeface = if (isSel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    private fun onChipClick(v: Float) {
        val cur = zoomDial.zoom
        if (abs(cur - v) < 0.05f) showDial() else camera?.cameraControl?.setZoomRatio(v)
    }

    private fun showDial() {
        if (panel != Panel.NONE || menuOpen) return
        dialVisible = true
        zoomDial.visibility = View.VISIBLE
        zoomRow.visibility = View.INVISIBLE
        sideCol.visibility = View.INVISIBLE
        pill.visibility = View.GONE
        scheduleHideDial()
    }

    private fun scheduleHideDial() {
        main.removeCallbacks(hideDial)
        main.postDelayed(hideDial, 2500)
    }

    private fun hideDialNow() {
        main.removeCallbacks(hideDial)
        dialVisible = false
        zoomDial.visibility = View.GONE
        if (panel == Panel.NONE) {
            zoomRow.visibility = View.VISIBLE
            sideCol.visibility = if (mode != Mode.VIDEO) View.VISIBLE else View.INVISIBLE
            pill.visibility = if (mode != Mode.VIDEO) View.VISIBLE else View.GONE
        }
    }

    private fun focusAt(x: Float, y: Float) {
        if (menuOpen) {
            closeMenu()
            return
        }
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        ).setAutoCancelDuration(4, TimeUnit.SECONDS).build()
        cam.cameraControl.startFocusAndMetering(action)

        val half = dp(72) / 2f
        focusRing.x = x - half
        focusRing.y = y - half
        focusRing.visibility = View.VISIBLE
        focusRing.scaleX = 1.4f
        focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).start()
        main.removeCallbacks(hideFocus)
        main.postDelayed(hideFocus, 1200)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ camera

    private fun requiredPermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        return l.toTypedArray()
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun videoQuality(): Quality = when (videoQ) {
        0 -> Quality.HD
        2 -> Quality.UHD
        else -> Quality.FHD
    }

    private fun captureAspect(): Int =
        if (mode == Mode.VIDEO || ratio == Ratio.R169 || ratio == Ratio.FULL) AspectRatio.RATIO_16_9
        else AspectRatio.RATIO_4_3

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        if (recording != null) return
        provider.unbindAll()
        updatePreviewLayout()

        val selector = if (lensFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val aspect = captureAspect()

        val pb = Preview.Builder().setTargetAspectRatio(aspect)
        val icb = ImageCapture.Builder()
            .setTargetAspectRatio(aspect)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)

        if (mode == Mode.PRO && manualExposure) {
            val ns = 1_000_000_000L / SHUTTER_DEN[proShutterIndex]
            val e1 = Camera2Interop.Extender(pb)
            e1.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            e1.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, proIso)
            e1.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, ns)
            val e2 = Camera2Interop.Extender(icb)
            e2.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            e2.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, proIso)
            e2.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, ns)
        }

        var fpsRange: Range<Int>? = null
        if (mode == Mode.VIDEO) {
            val want = if (videoFps == 1) 60 else 30
            fpsRange = pickFpsRange(selector, want)
            if (fpsRange != null) {
                Camera2Interop.Extender(pb)
                    .setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fpsRange)
            } else if (want == 60) {
                toast("60 fps not supported on this camera")
            }
        }
        val preview = pb.build()
        preview.setSurfaceProvider(previewView.surfaceProvider)
        val ic = icb.build()
        imageCapture = ic

        try {
            val cam: Camera
            if (mode == Mode.VIDEO) {
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            videoQuality(),
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                        )
                    )
                    .build()
                val vcb = VideoCapture.Builder(recorder)
                if (fpsRange != null) {
                    Camera2Interop.Extender(vcb)
                        .setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fpsRange)
                }
                val vc = vcb.build()
                videoCapture = vc
                cam = provider.bindToLifecycle(this, selector, preview, vc)
            } else {
                videoCapture = null
                cam = provider.bindToLifecycle(this, selector, preview, ic)
            }
            camera = cam

            zoomLive?.removeObserver(zoomObserver)
            zoomLive = cam.cameraInfo.zoomState
            zoomLive?.observe(this, zoomObserver)

            btnFlash.alpha = if (cam.cameraInfo.hasFlashUnit()) 1f else 0.3f
            btnFlash.isEnabled = cam.cameraInfo.hasFlashUnit()
            configureExposure(cam)
            applyFlash()
        } catch (e: Exception) {
            toast("Camera error: ${e.message}")
        }
    }

    private fun configureExposure(cam: Camera) {
        val state = cam.cameraInfo.exposureState
        if (!state.isExposureCompensationSupported) {
            evLower = 0
            evUpper = 0
            evStep = 0f
            seekEv.isEnabled = false
            seekEv2.isEnabled = false
            return
        }
        val r = state.exposureCompensationRange
        evLower = r.lower
        evUpper = r.upper
        evStep = state.exposureCompensationStep.toFloat()
        seekEv.max = max(1, evUpper - evLower)
        seekEv2.max = max(1, evUpper - evLower)
        seekEv.isEnabled = !manualExposure
        seekEv2.isEnabled = !manualExposure
        setEv(userEv)
    }

    private fun setEv(idx: Int) {
        userEv = idx.coerceIn(evLower, evUpper)
        val txt = "EV  %.1f".format(userEv * evStep)
        tvEv.text = txt
        tvEv2.text = txt
        if (seekEv.progress != userEv - evLower) seekEv.progress = userEv - evLower
        if (seekEv2.progress != userEv - evLower) seekEv2.progress = userEv - evLower
        val base = if (mode == Mode.NIGHT) max(userEv, (evUpper * 0.6f).toInt()) else userEv
        camera?.cameraControl?.setExposureCompensationIndex(base.coerceIn(evLower, evUpper))
        updateTopIcons()
    }

    // ------------------------------------------------------------------ shutter / photo

    private fun onShutter() {
        if (processingVideo) {
            toast("Applying colour look to the video, please wait")
            return
        }
        when {
            mode == Mode.VIDEO -> toggleRecording()
            intervalRunning -> stopInterval()
            countDown != null -> cancelCountdown()
            intervalEnabled -> startInterval()
            timerSeconds > 0 -> startCountdown()
            else -> takePhoto()
        }
    }

    private fun startInterval() {
        intervalRunning = true
        updateShutterBg()
        pill.isEnabled = false
        toast("Interval shooting: every ${intervalSec}s. Tap shutter to stop")
        intervalTick()
    }

    private fun stopInterval() {
        intervalRunning = false
        main.removeCallbacks(intervalRunnable)
        pill.isEnabled = true
        updateShutterBg()
    }

    private fun intervalTick() {
        if (!intervalRunning) return
        takePhoto { ok ->
            if (!intervalRunning) return@takePhoto
            if (ok) main.postDelayed(intervalRunnable, intervalSec * 1000L) else stopInterval()
        }
    }

    private fun flashScreen() {
        flashOverlay.alpha = 0.7f
        flashOverlay.animate().alpha(0f).setDuration(220).start()
    }

    private fun startCountdown() {
        tvCountdown.visibility = View.VISIBLE
        tvCountdown.text = timerSeconds.toString()
        countDown = object : CountDownTimer(timerSeconds * 1000L, 1000L) {
            override fun onTick(ms: Long) {
                tvCountdown.text = ((ms + 999) / 1000).toString()
            }

            override fun onFinish() {
                countDown = null
                tvCountdown.visibility = View.GONE
                takePhoto()
            }
        }.start()
    }

    private fun cancelCountdown() {
        countDown?.cancel()
        countDown = null
        tvCountdown.visibility = View.GONE
    }

    private fun takePhoto(onDone: ((Boolean) -> Unit)? = null) {
        val ic = imageCapture
        if (ic == null) {
            onDone?.invoke(false)
            return
        }
        val currentMode = mode
        val filterM = if (filterIndex == 0) null else Filters.all[filterIndex].matrix
        val beautyV = when (currentMode) {
            Mode.PORTRAIT -> max(beauty, 35)
            Mode.PHOTO -> beauty
            else -> 0
        }
        val mirror = lensFront && mirrorSelfie
        val stamp = if (watermarkOn)
            SimpleDateFormat("dd MMM yyyy  HH:mm", Locale.getDefault()).format(Date()) else null
        val aspect = previewAspect
        val hdrOn = autoHdr && currentMode != Mode.PRO
        val aiOn = aiEnhance
        val opts = { rotation: Int ->
            ImageProcessor.Options(
                rotation = rotation,
                mirror = mirror,
                cropAspect = aspect,
                filter = filterM,
                beauty = beautyV,
                night = currentMode == Mode.NIGHT,
                portrait = currentMode == Mode.PORTRAIT,
                autoHdr = hdrOn,
                aiEnhance = aiOn,
                watermark = stamp
            )
        }

        if (shutterSound) sound.play(MediaActionSound.SHUTTER_CLICK)
        flashScreen()

        ic.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                var ok = false
                try {
                    val raw = image.toBitmap()
                    val out = ImageProcessor.process(raw, opts(image.imageInfo.rotationDegrees))
                    val uri = saveBitmap(out)
                    if (uri != null) {
                        ok = true
                        runOnUiThread {
                            lastUri = uri
                            prefs.edit().putString("last_uri", uri.toString()).apply()
                            refreshThumb()
                        }
                    } else {
                        runOnUiThread { toast("Could not save photo (storage permission?)") }
                    }
                } catch (t: Throwable) {
                    runOnUiThread { toast("Capture failed: ${t.message}") }
                } finally {
                    image.close()
                    runOnUiThread { onDone?.invoke(ok) }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread {
                    toast("Capture failed: ${exception.message}")
                    onDone?.invoke(false)
                }
            }
        })
    }

    private fun saveBitmap(bmp: Bitmap): Uri? {
        val name = "IMG_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        return uri
    }

    @Suppress("DEPRECATION")
    private fun refreshThumb() {
        val uri = lastUri ?: return
        cameraExecutor.execute {
            val bmp: Bitmap? = try {
                if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(uri, Size(200, 200), null)
                } else {
                    MediaStore.Images.Media.getBitmap(contentResolver, uri)
                        ?.let { Bitmap.createScaledBitmap(it, 200, 200, true) }
                }
            } catch (e: Exception) {
                null
            }
            if (bmp != null) runOnUiThread { thumb.setImageBitmap(bmp) }
        }
    }

    // ------------------------------------------------------------------ video

    @SuppressLint("MissingPermission")
    private fun toggleRecording() {
        val vc = videoCapture ?: return
        val active = recording
        if (active != null) {
            active.stop()
            if (shutterSound) sound.play(MediaActionSound.STOP_VIDEO_RECORDING)
            return
        }

        val name = "VID_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
        }
        val options = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values)
            .build()

        var pending = vc.output.prepareRecording(this, options)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pending = pending.withAudioEnabled()
        }

        if (shutterSound) sound.play(MediaActionSound.START_VIDEO_RECORDING)
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    tvRec.text = "● 00:00"
                    tvRec.visibility = View.VISIBLE
                    updateShutterBg()
                }
                is VideoRecordEvent.Status -> {
                    val s = event.recordingStats.recordedDurationNanos / 1_000_000_000L
                    tvRec.text = "● %02d:%02d".format(s / 60, s % 60)
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    tvRec.visibility = View.GONE
                    updateShutterBg()
                    if (!event.hasError()) {
                        lastUri = event.outputResults.outputUri
                        prefs.edit().putString("last_uri", lastUri.toString()).apply()
                        refreshThumb()
                        val look = Filters.lookFor(filterIndex)
                        if (videoLook && look != null) bakeVideoLook(event.outputResults.outputUri, look)
                    } else {
                        toast("Recording failed")
                    }
                }
                else -> {}
            }
        }
    }

    /** Re-encodes the finished video with the selected colour filter and writes it over the original. */
    private fun bakeVideoLook(src: Uri, look: Filters.Look) {
        processingVideo = true
        toast("Applying ${Filters.all[filterIndex].name} look to video…")
        val out = java.io.File(cacheDir, "look_${System.currentTimeMillis()}.mp4")
        fun finish(msg: String?) {
            processingVideo = false
            out.delete()
            if (msg != null) toast(msg)
            refreshThumb()
        }
        try {
            VideoFilter.apply(this, src, look, out) { ok, err ->
                runOnUiThread {
                    if (!ok) {
                        finish("Colour look failed, original video kept ($err)")
                    } else {
                        Thread {
                            var msg: String? = null
                            try {
                                contentResolver.openOutputStream(src, "wt")!!.use { o ->
                                    out.inputStream().use { it.copyTo(o) }
                                }
                            } catch (t: Throwable) {
                                msg = "Could not save the filtered video: ${t.message}"
                            }
                            runOnUiThread { finish(msg) }
                        }.start()
                    }
                }
            }
        } catch (t: Throwable) {
            finish("Colour look failed, original video kept")
        }
    }

    // ------------------------------------------------------------------ settings

    private fun showSettings() {
        startActivity(android.content.Intent(this, SettingsActivity::class.java))
    }
}
