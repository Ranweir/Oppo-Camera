package com.opencam.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.camera2.CaptureRequest
import android.media.MediaActionSound
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.ZoomState
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private enum class Mode(val label: String) {
        NIGHT("NIGHT"), PORTRAIT("PORTRAIT"), PHOTO("PHOTO"), VIDEO("VIDEO"), PRO("PRO")
    }

    private enum class Panel { NONE, FILTERS, BEAUTY, PRO }

    private class SimpleSeek(
        val onChange: (Int, Boolean) -> Unit,
        val onStop: () -> Unit = {}
    ) : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) =
            onChange(progress, fromUser)

        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) = onStop()
    }

    companion object {
        private val SHUTTER_DEN = intArrayOf(4000, 2000, 1000, 500, 250, 125, 60, 30, 15, 8, 4)
        private val YELLOW = Color.parseColor("#F5C518")
    }

    // ---- views ----
    private lateinit var previewHost: FrameLayout
    private lateinit var previewContainer: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var gridOverlay: GridOverlayView
    private lateinit var focusRing: View
    private lateinit var tvRec: TextView
    private lateinit var tvCountdown: TextView
    private lateinit var zoomRow: LinearLayout
    private lateinit var zoomDial: ZoomDialView
    private lateinit var filterStrip: HorizontalScrollView
    private lateinit var filterRow: LinearLayout
    private lateinit var beautyPanel: LinearLayout
    private lateinit var tvBeauty: TextView
    private lateinit var seekBeauty: SeekBar
    private lateinit var proPanel: LinearLayout
    private lateinit var tvEv: TextView
    private lateinit var seekEv: SeekBar
    private lateinit var swManual: SwitchCompat
    private lateinit var tvIso: TextView
    private lateinit var seekIso: SeekBar
    private lateinit var tvShutter: TextView
    private lateinit var seekShutter: SeekBar
    private lateinit var flashOverlay: View
    private lateinit var modeScroll: HorizontalScrollView
    private lateinit var modeRow: LinearLayout
    private lateinit var thumb: ImageView
    private lateinit var shutter: FrameLayout
    private lateinit var shutterInner: View
    private lateinit var btnFlip: TextView
    private lateinit var btnSettings: TextView
    private lateinit var btnFlash: TextView
    private lateinit var btnTimer: TextView
    private lateinit var btnRatio: TextView
    private lateinit var btnBeauty: TextView
    private lateinit var btnFilters: TextView

    // ---- state ----
    private lateinit var prefs: SharedPreferences
    private lateinit var cameraExecutor: ExecutorService
    private val main = Handler(Looper.getMainLooper())
    private val sound by lazy { MediaActionSound() }

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var zoomLive: LiveData<ZoomState>? = null

    private var lensFront = false
    private var ratio169 = false
    private var mode = Mode.PHOTO
    private var panel = Panel.NONE
    private var flashMode = 0 // 0 auto, 1 on, 2 off
    private var timerSeconds = 0
    private var filterIndex = 0
    private var beauty = 0
    private var manualExposure = false
    private var proIso = 400
    private var proShutterIndex = 6
    private var proEv = 0
    private var evLower = 0
    private var evUpper = 0
    private var evStep = 0f
    private var lastUri: Uri? = null
    private var countDown: CountDownTimer? = null
    private var dialVisible = false

    // settings
    private var gridOn = false
    private var shutterSound = true
    private var mirrorSelfie = true
    private var volumeShutter = true
    private var videoQ = 1 // 0 HD, 1 FHD, 2 UHD

    private val modeViews = LinkedHashMap<Mode, TextView>()
    private val filterViews = ArrayList<TextView>()
    private val chips = ArrayList<Pair<Float, TextView>>()
    private var chipKey = ""

    private val hideDial = Runnable { hideDialNow() }
    private val hideFocus = Runnable { focusRing.visibility = View.GONE }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasCameraPermission()) startCamera()
            else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
        }

    private val zoomObserver = Observer<ZoomState> { zs ->
        zoomDial.minZoom = zs.minZoomRatio
        zoomDial.maxZoom = zs.maxZoomRatio
        zoomDial.zoom = zs.zoomRatio
        updateZoomChips(zs.zoomRatio, zs.minZoomRatio, zs.maxZoomRatio)
    }

    // ------------------------------------------------------------------ lifecycle

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("opencam", MODE_PRIVATE)
        cameraExecutor = Executors.newSingleThreadExecutor()

        bindViews()
        loadPrefs()
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER

        buildModeStrip()
        buildFilterStrip()
        setupListeners()
        applyModeUi()
        applyGrid()

        prefs.getString("last_uri", null)?.let { lastUri = Uri.parse(it) }
        refreshThumb()

        if (hasCameraPermission()) startCamera()
        else permissionLauncher.launch(requiredPermissions())
    }

    override fun onDestroy() {
        super.onDestroy()
        countDown?.cancel()
        cameraExecutor.shutdown()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (volumeShutter && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (event?.repeatCount == 0) shutter.performClick()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------------ setup

    private fun bindViews() {
        previewHost = findViewById(R.id.previewHost)
        previewContainer = findViewById(R.id.previewContainer)
        previewView = findViewById(R.id.previewView)
        gridOverlay = findViewById(R.id.gridOverlay)
        focusRing = findViewById(R.id.focusRing)
        tvRec = findViewById(R.id.tvRec)
        tvCountdown = findViewById(R.id.tvCountdown)
        zoomRow = findViewById(R.id.zoomRow)
        zoomDial = findViewById(R.id.zoomDial)
        filterStrip = findViewById(R.id.filterStrip)
        filterRow = findViewById(R.id.filterRow)
        beautyPanel = findViewById(R.id.beautyPanel)
        tvBeauty = findViewById(R.id.tvBeauty)
        seekBeauty = findViewById(R.id.seekBeauty)
        proPanel = findViewById(R.id.proPanel)
        tvEv = findViewById(R.id.tvEv)
        seekEv = findViewById(R.id.seekEv)
        swManual = findViewById(R.id.swManual)
        tvIso = findViewById(R.id.tvIso)
        seekIso = findViewById(R.id.seekIso)
        tvShutter = findViewById(R.id.tvShutter)
        seekShutter = findViewById(R.id.seekShutter)
        flashOverlay = findViewById(R.id.flashOverlay)
        modeScroll = findViewById(R.id.modeScroll)
        modeRow = findViewById(R.id.modeRow)
        thumb = findViewById(R.id.thumb)
        shutter = findViewById(R.id.shutter)
        shutterInner = findViewById(R.id.shutterInner)
        btnFlip = findViewById(R.id.btnFlip)
        btnSettings = findViewById(R.id.btnSettings)
        btnFlash = findViewById(R.id.btnFlash)
        btnTimer = findViewById(R.id.btnTimer)
        btnRatio = findViewById(R.id.btnRatio)
        btnBeauty = findViewById(R.id.btnBeauty)
        btnFilters = findViewById(R.id.btnFilters)
    }

    private fun loadPrefs() {
        gridOn = prefs.getBoolean("grid", false)
        shutterSound = prefs.getBoolean("sound", true)
        mirrorSelfie = prefs.getBoolean("mirror", true)
        volumeShutter = prefs.getBoolean("volume", true)
        videoQ = prefs.getInt("vq", 1)
        ratio169 = prefs.getBoolean("ratio169", false)
        beauty = prefs.getInt("beauty", 0)
        filterIndex = prefs.getInt("filter", 0).coerceIn(0, Filters.all.size - 1)
        seekBeauty.progress = beauty
        tvBeauty.text = "Beauty  $beauty"
        btnRatio.text = if (ratio169) "16:9" else "4:3"
        seekIso.progress = (proIso / 100) - 1
        seekShutter.progress = proShutterIndex
        tvIso.text = "ISO  $proIso"
        tvShutter.text = "Shutter  1/${SHUTTER_DEN[proShutterIndex]}"
        seekIso.isEnabled = false
        seekShutter.isEnabled = false
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupListeners() {
        previewHost.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updatePreviewSize() }

        // Pinch to zoom, tap to focus, swipe to change mode
        val scaleDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    val cam = camera ?: return true
                    val cur = cam.cameraInfo.zoomState.value?.zoomRatio ?: return true
                    cam.cameraControl.setZoomRatio(cur * detector.scaleFactor)
                    if (panel == Panel.NONE) showDial()
                    return true
                }
            })
        val gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusAt(e.x, e.y)
                return true
            }

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float
            ): Boolean {
                if (abs(velocityX) > abs(velocityY) && abs(velocityX) > 900f) {
                    val modes = Mode.values()
                    val i = modes.indexOf(mode) + if (velocityX < 0) 1 else -1
                    if (i in modes.indices) setMode(modes[i])
                    return true
                }
                return false
            }
        })
        previewView.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) gestureDetector.onTouchEvent(ev)
            true
        }

        zoomDial.onZoomChanged = { z -> camera?.cameraControl?.setZoomRatio(z) }
        zoomDial.onInteraction = { scheduleHideDial() }

        shutter.setOnClickListener {
            when {
                mode == Mode.VIDEO -> toggleRecording()
                countDown != null -> cancelCountdown()
                timerSeconds > 0 -> startCountdown()
                else -> takePhoto()
            }
        }

        btnFlip.setOnClickListener {
            if (recording != null) return@setOnClickListener
            lensFront = !lensFront
            btnFlip.animate().rotationBy(180f).setDuration(300).start()
            bindCamera()
        }

        btnFlash.setOnClickListener {
            flashMode = if (mode == Mode.VIDEO) {
                if (flashMode == 1) 2 else 1
            } else (flashMode + 1) % 3
            updateFlashUi()
            applyFlash()
        }

        btnTimer.setOnClickListener {
            timerSeconds = when (timerSeconds) { 0 -> 3; 3 -> 10; else -> 0 }
            btnTimer.text = if (timerSeconds == 0) "⏱" else "⏱$timerSeconds"
            btnTimer.setTextColor(if (timerSeconds == 0) Color.WHITE else YELLOW)
        }

        btnRatio.setOnClickListener {
            if (recording != null) return@setOnClickListener
            ratio169 = !ratio169
            prefs.edit().putBoolean("ratio169", ratio169).apply()
            btnRatio.text = if (ratio169) "16:9" else "4:3"
            bindCamera()
        }

        btnFilters.setOnClickListener { togglePanel(Panel.FILTERS) }
        btnBeauty.setOnClickListener { togglePanel(Panel.BEAUTY) }
        btnSettings.setOnClickListener { showSettings() }

        thumb.setOnClickListener {
            val u = lastUri ?: return@setOnClickListener
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(u, contentResolver.getType(u))
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } catch (e: Exception) {
                toast("No gallery app found")
            }
        }

        seekBeauty.setOnSeekBarChangeListener(SimpleSeek({ p, _ ->
            beauty = p
            tvBeauty.text = "Beauty  $p"
        }, { prefs.edit().putInt("beauty", beauty).apply() }))

        seekEv.setOnSeekBarChangeListener(SimpleSeek({ p, fromUser ->
            proEv = p + evLower
            tvEv.text = "EV  %.1f".format(proEv * evStep)
            if (fromUser) camera?.cameraControl?.setExposureCompensationIndex(proEv)
        }))

        seekIso.setOnSeekBarChangeListener(SimpleSeek({ p, _ ->
            proIso = (p + 1) * 100
            tvIso.text = "ISO  $proIso"
        }, { if (manualExposure) bindCamera() }))

        seekShutter.setOnSeekBarChangeListener(SimpleSeek({ p, _ ->
            proShutterIndex = p
            tvShutter.text = "Shutter  1/${SHUTTER_DEN[p]}"
        }, { if (manualExposure) bindCamera() }))

        swManual.setOnCheckedChangeListener { _, checked ->
            manualExposure = checked
            seekEv.isEnabled = !checked
            seekIso.isEnabled = checked
            seekShutter.isEnabled = checked
            bindCamera()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildModeStrip() {
        val pad = resources.displayMetrics.widthPixels / 2 - dp(40)
        modeRow.setPadding(pad, 0, pad, 0)
        for (m in Mode.values()) {
            val tv = TextView(this).apply {
                text = m.label
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(14), 0, dp(14), 0)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
                setOnClickListener { setMode(m) }
            }
            modeRow.addView(tv)
            modeViews[m] = tv
        }
    }

    private fun buildFilterStrip() {
        Filters.all.forEachIndexed { i, f ->
            val tv = TextView(this).apply {
                text = f.name
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(4) }
                setOnClickListener {
                    filterIndex = i
                    prefs.edit().putInt("filter", i).apply()
                    updateFilterUi()
                    applyLiveFilter()
                }
            }
            filterRow.addView(tv)
            filterViews.add(tv)
        }
        updateFilterUi()
    }

    // ------------------------------------------------------------------ UI state

    private fun setMode(m: Mode) {
        if (recording != null || m == mode || countDown != null) return
        mode = m
        panel = when {
            m == Mode.PRO -> Panel.PRO
            panel == Panel.PRO -> Panel.NONE
            m == Mode.VIDEO && (panel == Panel.FILTERS || panel == Panel.BEAUTY) -> Panel.NONE
            (m == Mode.NIGHT) && panel == Panel.BEAUTY -> Panel.NONE
            else -> panel
        }
        applyModeUi()
        bindCamera()
    }

    private fun applyModeUi() {
        for ((m, tv) in modeViews) {
            tv.setTextColor(if (m == mode) YELLOW else Color.WHITE)
            tv.typeface = if (m == mode) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        modeScroll.post {
            val v = modeViews[mode] ?: return@post
            modeScroll.smoothScrollTo(v.left + v.width / 2 - modeScroll.width / 2, 0)
        }
        val photoLike = mode != Mode.VIDEO
        btnBeauty.visibility = if (mode == Mode.PHOTO || mode == Mode.PORTRAIT) View.VISIBLE else View.GONE
        btnFilters.visibility = if (photoLike) View.VISIBLE else View.GONE
        btnTimer.visibility = if (photoLike) View.VISIBLE else View.GONE
        btnRatio.visibility = if (photoLike) View.VISIBLE else View.GONE
        updateShutterBg()
        updateFlashUi()
        refreshPanels()
        applyLiveFilter()
    }

    private fun updateShutterBg() {
        shutterInner.setBackgroundResource(
            when {
                recording != null -> R.drawable.shutter_inner_rec
                mode == Mode.VIDEO -> R.drawable.shutter_inner_video
                else -> R.drawable.shutter_inner_photo
            }
        )
    }

    private fun togglePanel(p: Panel) {
        panel = if (panel == p) (if (mode == Mode.PRO) Panel.PRO else Panel.NONE) else p
        hideDialNow()
        refreshPanels()
    }

    private fun refreshPanels() {
        val showFilters = panel == Panel.FILTERS && mode != Mode.VIDEO
        val showBeauty = panel == Panel.BEAUTY && (mode == Mode.PHOTO || mode == Mode.PORTRAIT)
        val showPro = mode == Mode.PRO && panel == Panel.PRO
        filterStrip.visibility = if (showFilters) View.VISIBLE else View.GONE
        beautyPanel.visibility = if (showBeauty) View.VISIBLE else View.GONE
        proPanel.visibility = if (showPro) View.VISIBLE else View.GONE
        val none = !showFilters && !showBeauty && !showPro
        if (!none) {
            zoomDial.visibility = View.GONE
            dialVisible = false
        }
        zoomRow.visibility = if (none && !dialVisible) View.VISIBLE else View.INVISIBLE
        btnFilters.setTextColor(if (filterIndex != 0 || showFilters) YELLOW else Color.WHITE)
        btnBeauty.setTextColor(if (beauty > 0 || showBeauty) YELLOW else Color.WHITE)
    }

    private fun updateFilterUi() {
        filterViews.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == filterIndex) YELLOW else Color.WHITE)
            tv.typeface = if (i == filterIndex) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        btnFilters.setTextColor(if (filterIndex != 0) YELLOW else Color.WHITE)
    }

    /** Applies the selected colour filter to the live preview. */
    private fun applyLiveFilter() {
        val cm = if (mode == Mode.VIDEO) null else Filters.all[filterIndex].matrix
        if (cm == null) {
            previewView.setLayerType(View.LAYER_TYPE_NONE, null)
        } else {
            val p = Paint()
            p.colorFilter = ColorMatrixColorFilter(cm)
            previewView.setLayerType(View.LAYER_TYPE_HARDWARE, p)
        }
    }

    private fun applyGrid() {
        gridOverlay.visibility = if (gridOn) View.VISIBLE else View.GONE
    }

    private fun updateFlashUi() {
        if (mode == Mode.VIDEO && flashMode == 0) flashMode = 2
        btnFlash.text = when (flashMode) { 0 -> "⚡A"; 1 -> "⚡"; else -> "⚡✕" }
        btnFlash.setTextColor(if (flashMode == 1) YELLOW else Color.WHITE)
    }

    private fun applyFlash() {
        imageCapture?.flashMode = when (flashMode) {
            0 -> ImageCapture.FLASH_MODE_AUTO
            1 -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        camera?.cameraControl?.enableTorch(mode == Mode.VIDEO && flashMode == 1)
    }

    private fun updatePreviewSize() {
        val w = previewHost.width
        val h = previewHost.height
        if (w == 0 || h == 0) return
        val r = if (ratio169 || mode == Mode.VIDEO) 16f / 9f else 4f / 3f
        val target = minOf((w * r).toInt(), h)
        val lp = previewContainer.layoutParams as FrameLayout.LayoutParams
        if (lp.height != target) {
            lp.height = target
            previewContainer.layoutParams = lp
        }
    }

    private fun fmt(v: Float): String =
        if (abs(v - Math.round(v)) < 0.05f) Math.round(v).toString() else "%.1f".format(v)

    private fun updateZoomChips(z: Float, minZ: Float, maxZ: Float) {
        val cand = floatArrayOf(0.6f, 1f, 2f, 5f, 10f).filter { it >= minZ - 0.01f && it <= maxZ + 0.01f }
        val key = cand.joinToString(",")
        if (key != chipKey) {
            chipKey = key
            zoomRow.removeAllViews()
            chips.clear()
            val size = dp(40)
            for (v in cand) {
                val tv = TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(size, size).apply {
                        marginStart = dp(5)
                        marginEnd = dp(5)
                    }
                    gravity = Gravity.CENTER
                    textSize = 12f
                    setBackgroundResource(R.drawable.bg_chip)
                    setOnClickListener { onChipClick(v) }
                    setOnLongClickListener { showDial(); true }
                }
                zoomRow.addView(tv)
                chips.add(v to tv)
            }
        }
        var selected = chips.firstOrNull()?.first
        for ((v, _) in chips) if (v <= z + 0.05f) selected = v
        for ((v, tv) in chips) {
            val isSel = v == selected
            tv.text = if (isSel) fmt(z) + "x" else fmt(v)
            tv.setTextColor(if (isSel) YELLOW else Color.WHITE)
        }
    }

    private fun onChipClick(v: Float) {
        val cur = zoomDial.zoom
        if (abs(cur - v) < 0.05f) showDial() else camera?.cameraControl?.setZoomRatio(v)
    }

    private fun showDial() {
        if (panel != Panel.NONE) return
        dialVisible = true
        zoomDial.visibility = View.VISIBLE
        zoomRow.visibility = View.INVISIBLE
        scheduleHideDial()
    }

    private fun scheduleHideDial() {
        main.removeCallbacks(hideDial)
        main.postDelayed(hideDial, 2500)
    }

    private fun hideDialNow() {
        main.removeCallbacks(hideDial)
        dialVisible = false
        zoomDial.visibility = View.GONE
        if (panel == Panel.NONE) zoomRow.visibility = View.VISIBLE
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        ).setAutoCancelDuration(4, TimeUnit.SECONDS).build()
        cam.cameraControl.startFocusAndMetering(action)

        val half = dp(72) / 2f
        focusRing.x = x - half
        focusRing.y = y - half
        focusRing.visibility = View.VISIBLE
        focusRing.scaleX = 1.4f
        focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).start()
        main.removeCallbacks(hideFocus)
        main.postDelayed(hideFocus, 1200)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ camera

    private fun requiredPermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        return l.toTypedArray()
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun videoQuality(): Quality = when (videoQ) {
        0 -> Quality.HD
        2 -> Quality.UHD
        else -> Quality.FHD
    }

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        if (recording != null) return
        provider.unbindAll()
        updatePreviewSize()

        val selector = if (lensFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val aspect = if (ratio169 || mode == Mode.VIDEO) AspectRatio.RATIO_16_9 else AspectRatio.RATIO_4_3

        val pb = Preview.Builder().setTargetAspectRatio(aspect)
        val icb = ImageCapture.Builder()
            .setTargetAspectRatio(aspect)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)

        if (mode == Mode.PRO && manualExposure) {
            val ns = 1_000_000_000L / SHUTTER_DEN[proShutterIndex]
            val e1 = Camera2Interop.Extender(pb)
            e1.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            e1.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, proIso)
            e1.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, ns)
            val e2 = Camera2Interop.Extender(icb)
            e2.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            e2.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, proIso)
            e2.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, ns)
        }

        val preview = pb.build()
        preview.setSurfaceProvider(previewView.surfaceProvider)
        val ic = icb.build()
        imageCapture = ic

        try {
            val cam: Camera
            if (mode == Mode.VIDEO) {
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            videoQuality(),
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                        )
                    )
                    .build()
                val vc = VideoCapture.withOutput(recorder)
                videoCapture = vc
                cam = provider.bindToLifecycle(this, selector, preview, vc)
            } else {
                videoCapture = null
                cam = provider.bindToLifecycle(this, selector, preview, ic)
            }
            camera = cam

            zoomLive?.removeObserver(zoomObserver)
            zoomLive = cam.cameraInfo.zoomState
            zoomLive?.observe(this, zoomObserver)

            btnFlash.visibility = if (cam.cameraInfo.hasFlashUnit()) View.VISIBLE else View.GONE
            configureExposure(cam)
            applyFlash()
        } catch (e: Exception) {
            toast("Camera error: ${e.message}")
        }
    }

    private fun configureExposure(cam: Camera) {
        val state = cam.cameraInfo.exposureState
        if (!state.isExposureCompensationSupported) {
            seekEv.isEnabled = false
            return
        }
        val r = state.exposureCompensationRange
        evLower = r.lower
        evUpper = r.upper
        evStep = state.exposureCompensationStep.toFloat()
        seekEv.max = max(1, evUpper - evLower)
        seekEv.isEnabled = !manualExposure

        val idx = when (mode) {
            Mode.NIGHT -> (evUpper * 0.6f).toInt()
            Mode.PRO -> proEv.coerceIn(evLower, evUpper)
            else -> 0
        }
        if (mode == Mode.PRO) {
            seekEv.progress = idx - evLower
            tvEv.text = "EV  %.1f".format(idx * evStep)
        }
        cam.cameraControl.setExposureCompensationIndex(idx.coerceIn(evLower, evUpper))
    }

    // ------------------------------------------------------------------ photo

    private fun flashScreen() {
        flashOverlay.alpha = 0.7f
        flashOverlay.animate().alpha(0f).setDuration(220).start()
    }

    private fun startCountdown() {
        tvCountdown.visibility = View.VISIBLE
        countDown = object : CountDownTimer(timerSeconds * 1000L, 1000L) {
            override fun onTick(ms: Long) {
                tvCountdown.text = ((ms + 999) / 1000).toString()
            }

            override fun onFinish() {
                countDown = null
                tvCountdown.visibility = View.GONE
                takePhoto()
            }
        }.start()
    }

    private fun cancelCountdown() {
        countDown?.cancel()
        countDown = null
        tvCountdown.visibility = View.GONE
    }

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val currentMode = mode
        val filterM = if (filterIndex == 0) null else Filters.all[filterIndex].matrix
        val beautyV = when (currentMode) {
            Mode.PORTRAIT -> max(beauty, 35)
            Mode.PHOTO -> beauty
            else -> 0
        }
        val mirror = lensFront && mirrorSelfie

        if (shutterSound) sound.play(MediaActionSound.SHUTTER_CLICK)
        flashScreen()

        ic.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rotation = image.imageInfo.rotationDegrees
                    val raw = image.toBitmap()
                    val out = ImageProcessor.process(
                        raw, rotation, mirror, filterM, beautyV,
                        currentMode == Mode.NIGHT, currentMode == Mode.PORTRAIT
                    )
                    val uri = saveBitmap(out)
                    runOnUiThread {
                        if (uri != null) {
                            lastUri = uri
                            prefs.edit().putString("last_uri", uri.toString()).apply()
                            refreshThumb()
                        } else {
                            toast("Could not save photo (storage permission?)")
                        }
                    }
                } catch (t: Throwable) {
                    runOnUiThread { toast("Capture failed: ${t.message}") }
                } finally {
                    image.close()
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { toast("Capture failed: ${exception.message}") }
            }
        })
    }

    private fun saveBitmap(bmp: Bitmap): Uri? {
        val name = "IMG_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        return uri
    }

    @Suppress("DEPRECATION")
    private fun refreshThumb() {
        val uri = lastUri ?: return
        cameraExecutor.execute {
            val bmp: Bitmap? = try {
                if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(uri, Size(200, 200), null)
                } else {
                    MediaStore.Images.Media.getBitmap(contentResolver, uri)
                        ?.let { Bitmap.createScaledBitmap(it, 200, 200, true) }
                }
            } catch (e: Exception) {
                null
            }
            if (bmp != null) runOnUiThread { thumb.setImageBitmap(bmp) }
        }
    }

    // ------------------------------------------------------------------ video

    @SuppressLint("MissingPermission")
    private fun toggleRecording() {
        val vc = videoCapture ?: return
        val active = recording
        if (active != null) {
            active.stop()
            if (shutterSound) sound.play(MediaActionSound.STOP_VIDEO_RECORDING)
            return
        }

        val name = "VID_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
        }
        val options = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values)
            .build()

        var pending = vc.output.prepareRecording(this, options)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pending = pending.withAudioEnabled()
        }

        if (shutterSound) sound.play(MediaActionSound.START_VIDEO_RECORDING)
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    tvRec.text = "● 00:00"
                    tvRec.visibility = View.VISIBLE
                    updateShutterBg()
                }
                is VideoRecordEvent.Status -> {
                    val s = event.recordingStats.recordedDurationNanos / 1_000_000_000L
                    tvRec.text = "● %02d:%02d".format(s / 60, s % 60)
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    tvRec.visibility = View.GONE
                    updateShutterBg()
                    if (!event.hasError()) {
                        lastUri = event.outputResults.outputUri
                        prefs.edit().putString("last_uri", lastUri.toString()).apply()
                        refreshThumb()
                    } else {
                        toast("Recording failed")
                    }
                }
                else -> {}
            }
        }
    }

    // ------------------------------------------------------------------ settings

    private fun showSettings() {
        val v = layoutInflater.inflate(R.layout.dialog_settings, null)
        val swGrid = v.findViewById<SwitchCompat>(R.id.swGrid)
        val swSound = v.findViewById<SwitchCompat>(R.id.swSound)
        val swMirror = v.findViewById<SwitchCompat>(R.id.swMirror)
        val swVolume = v.findViewById<SwitchCompat>(R.id.swVolume)
        val rg = v.findViewById<RadioGroup>(R.id.rgQuality)

        swGrid.isChecked = gridOn
        swSound.isChecked = shutterSound
        swMirror.isChecked = mirrorSelfie
        swVolume.isChecked = volumeShutter
        rg.check(
            when (videoQ) {
                0 -> R.id.rbHd
                2 -> R.id.rbUhd
                else -> R.id.rbFhd
            }
        )

        AlertDialog.Builder(this)
            .setTitle("Camera settings")
            .setView(v)
            .setPositiveButton("Save") { _, _ ->
                val oldQ = videoQ
                gridOn = swGrid.isChecked
                shutterSound = swSound.isChecked
                mirrorSelfie = swMirror.isChecked
                volumeShutter = swVolume.isChecked
                videoQ = when (rg.checkedRadioButtonId) {
                    R.id.rbHd -> 0
                    R.id.rbUhd -> 2
                    else -> 1
                }
                prefs.edit()
                    .putBoolean("grid", gridOn)
                    .putBoolean("sound", shutterSound)
                    .putBoolean("mirror", mirrorSelfie)
                    .putBoolean("volume", volumeShutter)
                    .putInt("vq", videoQ)
                    .apply()
                applyGrid()
                if (mode == Mode.VIDEO && oldQ != videoQ) bindCamera()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
