package com.opencam.camera

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.max

/** Post-processing applied to a captured photo before it is saved. */
object ImageProcessor {

    class Options(
        val rotation: Int,
        val mirror: Boolean,
        /** Final width / height of the saved (portrait) image. 0 = keep sensor ratio. */
        val cropAspect: Float,
        val filter: ColorMatrix?,
        val beauty: Int,
        val night: Boolean,
        val portrait: Boolean,
        val autoHdr: Boolean,
        val aiEnhance: Boolean,
        val watermark: String?
    )

    fun process(src: Bitmap, o: Options): Bitmap {
        var bmp = transform(src, o.rotation, o.mirror)
        bmp = crop(bmp, o.cropAspect)
        if (o.autoHdr && needsHdr(bmp)) bmp = hdr(bmp)
        if (o.beauty > 0) bmp = smooth(bmp, o.beauty)

        val cm = ColorMatrix()
        var any = false
        if (o.night) { cm.postConcat(nightMatrix()); any = true }
        if (o.aiEnhance) { cm.postConcat(aiMatrix()); any = true }
        if (o.filter != null) { cm.postConcat(o.filter); any = true }
        if (any) bmp = applyMatrix(bmp, cm)

        if (o.portrait) bmp = vignette(bmp)
        if (o.watermark != null) bmp = watermark(bmp, o.watermark)
        return bmp
    }

    private fun transform(src: Bitmap, rotation: Int, mirror: Boolean): Bitmap {
        if (rotation == 0 && !mirror) return src
        val m = Matrix()
        m.postRotate(rotation.toFloat())
        if (mirror) m.postScale(-1f, 1f)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun crop(src: Bitmap, aspect: Float): Bitmap {
        if (aspect <= 0f) return src
        val w = src.width
        val h = src.height
        val cur = w.toFloat() / h
        if (abs(cur - aspect) < 0.01f) return src
        return if (cur > aspect) {
            val nw = (h * aspect).toInt().coerceIn(1, w)
            Bitmap.createBitmap(src, (w - nw) / 2, 0, nw, h)
        } else {
            val nh = (w / aspect).toInt().coerceIn(1, h)
            Bitmap.createBitmap(src, 0, (h - nh) / 2, w, nh)
        }
    }

    private fun applyMatrix(src: Bitmap, cm: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(cm)
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    private fun nightMatrix(): ColorMatrix {
        val c = 0.92f
        val t = (1f - c) * 128f + 26f
        return ColorMatrix(
            floatArrayOf(
                c * 1.05f, 0f, 0f, 0f, t,
                0f, c * 1.05f, 0f, 0f, t,
                0f, 0f, c * 1.05f, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    /** "AI enhance": slightly richer colour and contrast. */
    private fun aiMatrix(): ColorMatrix {
        val sat = ColorMatrix()
        sat.setSaturation(1.15f)
        val c = 1.08f
        val t = (1f - c) * 128f
        val con = ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
        sat.postConcat(con)
        return sat
    }

    /** True when the picture has a wide brightness range (bright sky + dark shadows). */
    private fun needsHdr(b: Bitmap): Boolean {
        val n = 32
        val l = IntArray(n * n)
        var k = 0
        for (j in 0 until n) {
            for (i in 0 until n) {
                val p = b.getPixel((i * (b.width - 1)) / (n - 1), (j * (b.height - 1)) / (n - 1))
                l[k++] = (((p shr 16) and 255) * 30 + ((p shr 8) and 255) * 59 + (p and 255) * 11) / 100
            }
        }
        l.sort()
        return l[(n * n * 95) / 100] - l[(n * n * 5) / 100] > 140
    }

    /** Software HDR-style tone curve: lifts shadows and mid-tones, keeps highlights. */
    private fun hdr(src: Bitmap): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val lut = IntArray(256) { i ->
            val x = i / 255f
            val y = x + 0.7f * x * (1f - x) * (1f - x)
            (y * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        val w = out.width
        val h = out.height
        val rows = 256
        val buf = IntArray(w * rows)
        var y0 = 0
        while (y0 < h) {
            val n = minOf(rows, h - y0)
            out.getPixels(buf, 0, w, 0, y0, w, n)
            for (i in 0 until w * n) {
                val p = buf[i]
                buf[i] = (p and 0xFF000000.toInt()) or
                    (lut[(p shr 16) and 0xFF] shl 16) or
                    (lut[(p shr 8) and 0xFF] shl 8) or
                    lut[p and 0xFF]
            }
            out.setPixels(buf, 0, w, 0, y0, w, n)
            y0 += n
        }
        return out
    }

    /** Skin-smoothing style effect: blends a blurred copy and brightens slightly. */
    private fun smooth(src: Bitmap, strength: Int): Bitmap {
        val s = strength.coerceIn(0, 100) / 100f
        val half = Bitmap.createScaledBitmap(src, max(1, src.width / 2), max(1, src.height / 2), true)
        val small = Bitmap.createScaledBitmap(half, max(1, src.width / 6), max(1, src.height / 6), true)
        val blurred = Bitmap.createScaledBitmap(small, src.width, src.height, true)

        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawBitmap(src, 0f, 0f, null)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.alpha = (s * 0.65f * 255f).toInt()
        canvas.drawBitmap(blurred, 0f, 0f, paint)

        return applyMatrix(out, Filters.bright(16f * s))
    }

    /** Soft dark edges for the Portrait mode. */
    private fun vignette(src: Bitmap): Bitmap {
        val out = if (src.isMutable) src else src.copy(Bitmap.Config.ARGB_8888, true)
        val w = out.width.toFloat()
        val h = out.height.toFloat()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = RadialGradient(
            w / 2f, h / 2f, max(w, h) * 0.75f,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(110, 0, 0, 0)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        Canvas(out).drawRect(0f, 0f, w, h, paint)
        return out
    }

    /** Date/time stamp in the bottom-left corner. */
    private fun watermark(src: Bitmap, text: String): Bitmap {
        val out = if (src.isMutable) src else src.copy(Bitmap.Config.ARGB_8888, true)
        val size = out.width * 0.035f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.WHITE
        paint.textSize = size
        paint.setShadowLayer(size * 0.15f, 0f, 0f, Color.BLACK)
        Canvas(out).drawText(text, size, out.height - size, paint)
        return out
    }
}
