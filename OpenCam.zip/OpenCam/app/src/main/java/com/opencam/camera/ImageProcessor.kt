package com.opencam.camera

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.max

/** Post-processing applied to a captured photo before it is saved. */
object ImageProcessor {

    fun process(
        src: Bitmap,
        rotation: Int,
        mirror: Boolean,
        filter: ColorMatrix?,
        beauty: Int,
        night: Boolean,
        portrait: Boolean
    ): Bitmap {
        var bmp = transform(src, rotation, mirror)
        if (night) bmp = applyMatrix(bmp, nightMatrix())
        if (beauty > 0) bmp = smooth(bmp, beauty)
        if (filter != null) bmp = applyMatrix(bmp, filter)
        if (portrait) bmp = vignette(bmp)
        return bmp
    }

    private fun transform(src: Bitmap, rotation: Int, mirror: Boolean): Bitmap {
        if (rotation == 0 && !mirror) return src
        val m = Matrix()
        m.postRotate(rotation.toFloat())
        if (mirror) m.postScale(-1f, 1f)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun applyMatrix(src: Bitmap, cm: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(cm)
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    /** Lifts shadows/brightness for the Night mode. */
    private fun nightMatrix(): ColorMatrix {
        val c = 0.92f
        val t = (1f - c) * 128f + 26f
        return ColorMatrix(
            floatArrayOf(
                c * 1.05f, 0f, 0f, 0f, t,
                0f, c * 1.05f, 0f, 0f, t,
                0f, 0f, c * 1.05f, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    /** Skin-smoothing style effect: blends a blurred copy and brightens slightly. */
    private fun smooth(src: Bitmap, strength: Int): Bitmap {
        val s = strength.coerceIn(0, 100) / 100f
        val half = Bitmap.createScaledBitmap(src, max(1, src.width / 2), max(1, src.height / 2), true)
        val small = Bitmap.createScaledBitmap(half, max(1, src.width / 6), max(1, src.height / 6), true)
        val blurred = Bitmap.createScaledBitmap(small, src.width, src.height, true)

        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawBitmap(src, 0f, 0f, null)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.alpha = (s * 0.65f * 255f).toInt()
        canvas.drawBitmap(blurred, 0f, 0f, paint)

        return applyMatrix(out, Filters.bright(16f * s))
    }

    /** Soft dark edges to give the Portrait mode a focused-subject look. */
    private fun vignette(src: Bitmap): Bitmap {
        val out = if (src.isMutable) src else src.copy(Bitmap.Config.ARGB_8888, true)
        val w = out.width.toFloat()
        val h = out.height.toFloat()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = RadialGradient(
            w / 2f, h / 2f, max(w, h) * 0.75f,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(110, 0, 0, 0)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        Canvas(out).drawRect(0f, 0f, w, h, paint)
        return out
    }
}
